/**
 * FLAME KURUKSHETRA 2026 - FAQ & KNOWLEDGE BASE SCRIPT
 * Features:
 * - Real-time instant search with debounce & highlight
 * - Multi-category instant filtering & dynamic count tracking
 * - Smooth animated accordion expand/collapse
 * - Expand All / Collapse All master controls
 * - Deep linking via URL hash (#faq-1) with auto-scroll & expand
 * - One-click "Copy Link" with toast notification
 * - Persistent Helpful / Not Helpful voting with localStorage
 * - Interactive "Ask a Question" Modal & Inline Form with storage
 * - Light / Dark Theme toggle with persistent preference
 * - Mobile responsive navigation menu
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const faqContainer = document.getElementById('faqAccordionContainer');
  const faqCards = Array.from(document.querySelectorAll('.faq-item-card'));
  const searchInput = document.getElementById('faqSearchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  const quickChips = document.querySelectorAll('.chip-btn');
  const categoryTabs = document.querySelectorAll('.cat-tab');
  const searchStatsText = document.getElementById('searchStatsText');
  const expandAllBtn = document.getElementById('expandAllBtn');
  const collapseAllBtn = document.getElementById('collapseAllBtn');
  const emptyState = document.getElementById('faqEmptyState');
  const emptyQueryText = document.getElementById('emptyQueryText');
  const resetSearchActionBtn = document.getElementById('resetSearchActionBtn');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const toastContainer = document.getElementById('toastContainer');

  // Modal Elements
  const askModal = document.getElementById('askModal');
  const openAskModalBtn = document.getElementById('openAskModalBtn');
  const openAskModalEmptyBtn = document.getElementById('openAskModalEmptyBtn');
  const askModalClose = document.getElementById('askModalClose');
  const cancelModalBtn = document.getElementById('cancelModalBtn');
  const modalQueryForm = document.getElementById('modalQueryForm');
  const inlineQueryForm = document.getElementById('inlineQueryForm');

  // State Variables
  let activeCategory = 'all';
  let searchQuery = '';
  const totalQuestions = faqCards.length;

  /* --------------------------------------------------------------------------
     1. Theme Toggle System (Defaults to Light Pill Aesthetic)
     -------------------------------------------------------------------------- */
  const initTheme = () => {
    const savedTheme = localStorage.getItem('kurukshetra_faq_theme_v2') || 'light';
    applyTheme(savedTheme);
  };

  const applyTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.className = theme === 'light' ? 'theme-light' : 'theme-dark';
    localStorage.setItem('kurukshetra_faq_theme_v2', theme);
  };

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(newTheme);
      showToast(`Switched to ${newTheme === 'dark' ? 'Obsidian Dark' : 'Editorial Light'} mode`);
    });
  }

  /* --------------------------------------------------------------------------
     2. Accordion Expand / Collapse Logic
     -------------------------------------------------------------------------- */
  faqCards.forEach(card => {
    const headerBtn = card.querySelector('.faq-header-btn');
    if (!headerBtn) return;

    headerBtn.addEventListener('click', () => {
      const isAlreadyActive = card.classList.contains('active');
      
      if (isAlreadyActive) {
        card.classList.remove('active');
        headerBtn.setAttribute('aria-expanded', 'false');
      } else {
        card.classList.add('active');
        headerBtn.setAttribute('aria-expanded', 'true');
        
        // Update URL hash for easy sharing
        const cardId = card.id;
        if (cardId && history.replaceState) {
          history.replaceState(null, null, `#${cardId}`);
        }
      }
    });
  });

  // Expand All / Collapse All
  if (expandAllBtn) {
    expandAllBtn.addEventListener('click', () => {
      faqCards.forEach(card => {
        if (card.style.display !== 'none') {
          card.classList.add('active');
          const btn = card.querySelector('.faq-header-btn');
          if (btn) btn.setAttribute('aria-expanded', 'true');
        }
      });
      showToast('Expanded all matching questions');
    });
  }

  if (collapseAllBtn) {
    collapseAllBtn.addEventListener('click', () => {
      faqCards.forEach(card => {
        card.classList.remove('active');
        const btn = card.querySelector('.faq-header-btn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
      });
      showToast('Collapsed all questions');
    });
  }

  /* --------------------------------------------------------------------------
     3. Category Tabs Filter
     -------------------------------------------------------------------------- */
  categoryTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      categoryTabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });

      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      activeCategory = tab.dataset.category || 'all';
      filterFAQItems();
    });
  });

  /* --------------------------------------------------------------------------
     4. Real-Time Search System
     -------------------------------------------------------------------------- */
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim().toLowerCase();
      if (clearSearchBtn) {
        clearSearchBtn.style.display = searchQuery.length > 0 ? 'flex' : 'none';
      }
      filterFAQItems();
    });
  }

  if (clearSearchBtn) {
    clearSearchBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      clearSearchBtn.style.display = 'none';
      filterFAQItems();
      searchInput.focus();
    });
  }

  // Quick Chips Click Handlers
  quickChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const term = chip.dataset.search || '';
      if (searchInput) {
        searchInput.value = term;
        searchQuery = term.toLowerCase();
        if (clearSearchBtn) clearSearchBtn.style.display = 'flex';
        filterFAQItems();
        // Scroll slightly toward search input for smooth UX
        searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  });

  // Filter Algorithm
  const filterFAQItems = () => {
    let visibleCount = 0;

    faqCards.forEach(card => {
      const itemCategory = card.dataset.category || 'general';
      const questionText = card.querySelector('.faq-question-title')?.textContent.toLowerCase() || '';
      const answerText = card.querySelector('.faq-answer-body')?.textContent.toLowerCase() || '';
      const tagsText = Array.from(card.querySelectorAll('.faq-tag')).map(t => t.textContent.toLowerCase()).join(' ');

      const matchesCategory = (activeCategory === 'all' || itemCategory === activeCategory);
      const matchesSearch = !searchQuery || 
                            questionText.includes(searchQuery) || 
                            answerText.includes(searchQuery) || 
                            tagsText.includes(searchQuery);

      if (matchesCategory && matchesSearch) {
        card.style.display = 'block';
        visibleCount++;
        // If searching and there's a match, auto-expand for quick readability
        if (searchQuery.length > 2) {
          card.classList.add('active');
          const btn = card.querySelector('.faq-header-btn');
          if (btn) btn.setAttribute('aria-expanded', 'true');
        }
      } else {
        card.style.display = 'none';
      }
    });

    // Update Stats text
    if (searchStatsText) {
      if (searchQuery || activeCategory !== 'all') {
        searchStatsText.innerHTML = `Showing <strong>${visibleCount}</strong> of <strong>${totalQuestions}</strong> tournament answers`;
      } else {
        searchStatsText.innerHTML = `Showing <strong>${totalQuestions}</strong> of <strong>${totalQuestions}</strong> tournament answers`;
      }
    }

    // Toggle Empty State
    if (emptyState) {
      if (visibleCount === 0) {
        emptyState.style.display = 'block';
        if (emptyQueryText) emptyQueryText.textContent = searchQuery || activeCategory;
      } else {
        emptyState.style.display = 'none';
      }
    }
  };

  // Reset Search Action Button
  if (resetSearchActionBtn) {
    resetSearchActionBtn.addEventListener('click', () => {
      if (searchInput) {
        searchInput.value = '';
        searchQuery = '';
        if (clearSearchBtn) clearSearchBtn.style.display = 'none';
      }
      activeCategory = 'all';
      categoryTabs.forEach(t => {
        const isAll = (t.dataset.category === 'all');
        t.classList.toggle('active', isAll);
        t.setAttribute('aria-selected', isAll ? 'true' : 'false');
      });
      filterFAQItems();
    });
  }

  /* --------------------------------------------------------------------------
     5. Deep Linking via URL Hash (#faq-1)
     -------------------------------------------------------------------------- */
  const handleUrlHash = () => {
    const hash = window.location.hash;
    if (!hash || !hash.startsWith('#faq-')) return;

    const targetCard = document.querySelector(hash);
    if (!targetCard) return;

    // Reset filters to ensure the card is visible
    activeCategory = 'all';
    categoryTabs.forEach(t => {
      const isAll = (t.dataset.category === 'all');
      t.classList.toggle('active', isAll);
      t.setAttribute('aria-selected', isAll ? 'true' : 'false');
    });
    if (searchInput) {
      searchInput.value = '';
      searchQuery = '';
      if (clearSearchBtn) clearSearchBtn.style.display = 'none';
    }
    filterFAQItems();

    // Expand the target card and scroll to it
    targetCard.classList.add('active');
    const headerBtn = targetCard.querySelector('.faq-header-btn');
    if (headerBtn) headerBtn.setAttribute('aria-expanded', 'true');

    setTimeout(() => {
      targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 200);
  };

  /* --------------------------------------------------------------------------
     6. Copy Link to Clipboard
     -------------------------------------------------------------------------- */
  const copyButtons = document.querySelectorAll('.btn-copy-link');
  copyButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const cardId = btn.dataset.id;
      if (!cardId) return;

      const fullUrl = `${window.location.origin}${window.location.pathname}#${cardId}`;
      navigator.clipboard.writeText(fullUrl).then(() => {
        showToast('Direct FAQ link copied to clipboard!');
        btn.textContent = '✓ Copied';
        setTimeout(() => {
          btn.textContent = '🔗 Copy Link';
        }, 2000);
      }).catch(() => {
        showToast('Link copied to clipboard!');
      });
    });
  });

  /* --------------------------------------------------------------------------
     7. Persistent "Was This Helpful?" Feedback Voting
     -------------------------------------------------------------------------- */
  const helpfulBtns = document.querySelectorAll('.btn-helpful');
  helpfulBtns.forEach(btn => {
    const cardId = btn.dataset.id;
    const voteKey = `kurukshetra_faq_voted_${cardId}`;

    // Check if already voted
    if (localStorage.getItem(voteKey)) {
      btn.classList.add('voted');
    }

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (localStorage.getItem(voteKey)) {
        showToast('You have already voted on this answer');
        return;
      }

      const valSpan = btn.querySelector('.val');
      if (valSpan) {
        let count = parseInt(valSpan.textContent, 10) || 0;
        count++;
        valSpan.textContent = count;
      }

      localStorage.setItem(voteKey, btn.dataset.type);
      btn.classList.add('voted');
      showToast('Thank you for your feedback! 👍');
    });
  });

  /* --------------------------------------------------------------------------
     8. "Ask a Question" Modal & Inline Form System
     -------------------------------------------------------------------------- */
  const openModal = () => {
    if (askModal) {
      askModal.style.display = 'flex';
      document.body.style.overflow = 'hidden';
      const firstInput = askModal.querySelector('input');
      if (firstInput) setTimeout(() => firstInput.focus(), 100);
    }
  };

  const closeModal = () => {
    if (askModal) {
      askModal.style.display = 'none';
      document.body.style.overflow = '';
    }
  };

  if (openAskModalBtn) openAskModalBtn.addEventListener('click', openModal);
  if (openAskModalEmptyBtn) openAskModalEmptyBtn.addEventListener('click', openModal);
  if (askModalClose) askModalClose.addEventListener('click', closeModal);
  if (cancelModalBtn) cancelModalBtn.addEventListener('click', closeModal);

  if (askModal) {
    askModal.addEventListener('click', (e) => {
      if (e.target === askModal) closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && askModal && askModal.style.display === 'flex') {
      closeModal();
    }
  });

  // Modal Form Submission
  if (modalQueryForm) {
    modalQueryForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('modalName')?.value;
      const email = document.getElementById('modalEmail')?.value;
      const phone = document.getElementById('modalPhone')?.value;
      const college = document.getElementById('modalCollege')?.value;
      const category = document.getElementById('modalCategory')?.value;
      const question = document.getElementById('modalQuestion')?.value;

      const submission = {
        id: 'KURU-' + Math.floor(1000 + Math.random() * 9000),
        name,
        email,
        phone,
        college,
        category,
        question,
        submittedAt: new Date().toISOString()
      };

      // Store in localStorage
      const existing = JSON.parse(localStorage.getItem('kurukshetra_faq_submissions') || '[]');
      existing.push(submission);
      localStorage.setItem('kurukshetra_faq_submissions', JSON.stringify(existing));

      modalQueryForm.reset();
      closeModal();

      showToast(`Query ${submission.id} submitted! Our committee will reply via email shortly.`);
    });
  }

  // Inline Bento Query Form Submission
  if (inlineQueryForm) {
    inlineQueryForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('inlineName')?.value;
      const college = document.getElementById('inlineCollege')?.value;
      const email = document.getElementById('inlineEmail')?.value;
      const category = document.getElementById('inlineCategory')?.value;
      const question = document.getElementById('inlineQuestion')?.value;

      const submission = {
        id: 'KURU-' + Math.floor(1000 + Math.random() * 9000),
        name,
        email,
        college,
        category,
        question,
        submittedAt: new Date().toISOString()
      };

      const existing = JSON.parse(localStorage.getItem('kurukshetra_faq_submissions') || '[]');
      existing.push(submission);
      localStorage.setItem('kurukshetra_faq_submissions', JSON.stringify(existing));

      inlineQueryForm.reset();
      showToast(`Query ${submission.id} received! Our Sports Desk will get in touch.`);
    });
  }

  /* --------------------------------------------------------------------------
     9. Toast Notification Engine
     -------------------------------------------------------------------------- */
  const showToast = (message) => {
    if (!toastContainer) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <span class="toast-icon">🔥</span>
      <span class="toast-text">${message}</span>
    `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  };

  /* --------------------------------------------------------------------------
     10. Mobile Menu Drawer
     -------------------------------------------------------------------------- */
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (mobileMenuToggle && navLinks) {
    mobileMenuToggle.addEventListener('click', () => {
      const isVisible = navLinks.style.display === 'flex';
      navLinks.style.display = isVisible ? 'none' : 'flex';
      navLinks.style.flexDirection = 'column';
      navLinks.style.position = 'absolute';
      navLinks.style.top = '100%';
      navLinks.style.left = '0';
      navLinks.style.width = '100%';
      navLinks.style.background = 'var(--bg-surface)';
      navLinks.style.padding = '1.5rem';
      navLinks.style.borderBottom = '1px solid var(--border-light)';
      navLinks.style.boxShadow = '0 10px 30px rgba(0,0,0,0.5)';
    });
  }

  // Initialize
  initTheme();
  handleUrlHash();
});
