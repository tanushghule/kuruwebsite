/**
 * FLAME KURUKSHETRA 2026 - MASTER SCHEDULE CONTROLLER (LIGHT EDITORIAL)
 * Clean, smooth, zero-clutter day breakdown & instant event dates lookup.
 */

document.addEventListener('DOMContentLoaded', () => {

  // =========================================================================
  // 1. OFFICIAL EVENTS DATABASE (20 Kurukshetra Disciplines)
  // =========================================================================
  const eventsDatabase = [
    {
      id: "football",
      name: "Football Championship",
      category: "sports",
      categoryLabel: "Collegiate Sports",
      days: [1, 2, 3],
      datesText: "Oct 24 — 26",
      venue: "FLAME Main Turf Arena",
      format: "11v11 Knockout (90 Mins + ET)",
      desc: "Western India's premier collegiate football tournament with certified national referees, floodlit championship turf, and high-intensity knockouts.",
      prize: "₹45,000 + Phoenix Cup"
    },
    {
      id: "cricket",
      name: "Kurukshetra T20 Trophy",
      category: "sports",
      categoryLabel: "Collegiate Sports",
      days: [1, 2, 3, 4],
      datesText: "Oct 24 — 27",
      venue: "FLAME Cricket Oval",
      format: "T20 White-Ball Knockouts",
      desc: "Inter-collegiate 20-over battle on turf pitches featuring electronic scoring, white Kookaburra balls, and floodlights.",
      prize: "₹50,000 + Phoenix Trophy"
    },
    {
      id: "tennis",
      name: "Tennis & Padel Open",
      category: "sports",
      categoryLabel: "Racket Sports",
      days: [1, 2, 3],
      datesText: "Oct 24 — 26",
      venue: "Center Court & Padel Glass Arena",
      format: "Singles & Doubles Best of 3 Sets",
      desc: "Professional synthetic courts and state-of-the-art panoramic padel enclosures for high-velocity baseline duels.",
      prize: "₹30,000 + Championship Medals"
    },
    {
      id: "basketball",
      name: "Basketball Slam",
      category: "sports",
      categoryLabel: "Collegiate Sports",
      days: [2, 3, 4],
      datesText: "Oct 25 — 27",
      venue: "Indoor Wooden Championship Court",
      format: "FIBA 5v5 Full-Court (4 Quarters)",
      desc: "Fierce indoor hardwood action featuring FIBA official scoreboards, 24-second shot clocks, and dunk contests.",
      prize: "₹35,000 + MVP Honors"
    },
    {
      id: "table-tennis",
      name: "Table Tennis Invitational",
      category: "sports",
      categoryLabel: "Racket Sports",
      days: [1, 2],
      datesText: "Oct 24 — 25",
      venue: "Indoor Sports Complex (Hall B)",
      format: "Singles & Mixed Team Knockout",
      desc: "ITTF-standard Stag tournament tables, precision rubber regulations, and rapid-fire table rallies.",
      prize: "₹20,000 + Medals"
    },
    {
      id: "badminton",
      name: "Badminton Masters",
      category: "sports",
      categoryLabel: "Racket Sports",
      days: [1, 2, 3],
      datesText: "Oct 24 — 26",
      venue: "Indoor Badminton Arena (4 Synthetic Courts)",
      format: "BWF Best of 3 Sets (21 Points)",
      desc: "High-flying smashes and drop shots on cushioned synthetic courts under glare-free arena lighting.",
      prize: "₹25,000 + Phoenix Trophies"
    },
    {
      id: "volleyball",
      name: "Volleyball Spike Cup",
      category: "sports",
      categoryLabel: "Collegiate Sports",
      days: [2, 3, 4],
      datesText: "Oct 25 — 27",
      venue: "Outdoor Floodlit Volleyball Arena",
      format: "6v6 Best of 5 Sets (25 Points)",
      desc: "High-intensity blocking and explosive spikes on regulation outdoor courts under the floodlights.",
      prize: "₹28,000 + Medals"
    },
    {
      id: "athletics",
      name: "Athletics & Sprint Track",
      category: "sports",
      categoryLabel: "Track & Field",
      days: [1, 4],
      datesText: "Oct 24 & 27",
      venue: "Olympic-Standard 400m Synthetic Track",
      format: "Heats & Timed Finals (100m, 400m, 4x100m)",
      desc: "Electronic gun start, laser photo-finish timing, and roaring collegiate crowds across sprint and relay finals.",
      prize: "₹30,000 + Individual Laurels"
    },
    {
      id: "swimming",
      name: "Swimming Gala",
      category: "sports",
      categoryLabel: "Aquatic Sports",
      days: [2, 3],
      datesText: "Oct 25 — 26",
      venue: "Olympic-Length 50m Aquatic Center",
      format: "Freestyle, Butterfly, Breaststroke & Relays",
      desc: "Heated competition lanes with touch-pad electronic timing and dedicated spectator gallery.",
      prize: "₹25,000 + Medals"
    },
    {
      id: "band-battle",
      name: "Battle of the Bands",
      category: "cultural",
      categoryLabel: "Live Music & Stage",
      days: [2],
      datesText: "Oct 25 (Evening)",
      venue: "Main Campus Amphitheater",
      format: "Live Band Performance (20-Min Slot)",
      desc: "The ultimate collegiate rock and fusion showdown under a concert-grade PA system with 2,000+ live spectators.",
      prize: "₹50,000 + Studio Recording Time"
    },
    {
      id: "street-dance",
      name: "Step Up: Street Dance",
      category: "cultural",
      categoryLabel: "Dance & Urban Arts",
      days: [3],
      datesText: "Oct 26",
      venue: "Central Plaza Stage",
      format: "Crew Routine & 1v1 Cypher Battles",
      desc: "Fierce hip-hop, breaking, popping, and urban choreography battles adjudicated by celebrity dancers.",
      prize: "₹35,000 + Trophy"
    },
    {
      id: "kalakaar-katta",
      name: "Kalakaar Katta Unplugged",
      category: "cultural",
      categoryLabel: "Acoustic & Poetry",
      days: [1, 2],
      datesText: "Oct 24 — 25",
      venue: "Katta Circle Courtyard",
      format: "Acoustic Sets, Spoken Word & Slams",
      desc: "Intimate evening open mics, soulful indie acoustic jams, and expressive spoken-word poetry under fairy-lit trees.",
      prize: "₹20,000 + Featured Spot"
    },
    {
      id: "fashion-show",
      name: "Fashion Show: Phoenix Walk",
      category: "cultural",
      categoryLabel: "Fashion & Design",
      days: [3],
      datesText: "Oct 26 (Night)",
      venue: "Main Amphitheater Runway",
      format: "Thematic Ramp Walk & Presentation",
      desc: "Avant-garde and sustainable fashion interpretations created and modeled by top design institutes.",
      prize: "₹40,000 + Best Model Honors"
    },
    {
      id: "standup",
      name: "Stand-Up Comedy Night",
      category: "cultural",
      categoryLabel: "Literary & Comedy",
      days: [1],
      datesText: "Oct 24 (Evening)",
      venue: "Auditorium Hall 1",
      format: "Solo 7-Minute Open Stand-Up Set",
      desc: "Sharp observational wit, punchlines, and crowd work judged by headline stand-up artists.",
      prize: "₹15,000 + Festival Opener Spot"
    },
    {
      id: "shark-arena",
      name: "Shark Arena: B-Plan",
      category: "me",
      categoryLabel: "Entrepreneurship",
      days: [2],
      datesText: "Oct 25",
      venue: "Venture War Room (Auditorium)",
      format: "10-Min Pitch + 5-Min Shark Q&A",
      desc: "Collegiate venture pitch competition judged by prominent Angel Investors, VC partners, and startup founders.",
      prize: "₹60,000 Seed Grant"
    },
    {
      id: "crisis-sim",
      name: "Corporate Crisis Simulation",
      category: "me",
      categoryLabel: "Management Strategy",
      days: [1],
      datesText: "Oct 24",
      venue: "Executive Council Chambers",
      format: "Escalating PR & Boardroom War Room",
      desc: "Teams navigate market shocks, stock volatility, hostile takeovers, and media press conferences under extreme time pressure.",
      prize: "₹25,000 + Mentorship"
    },
    {
      id: "dalal-street",
      name: "Wolf of Dalal Street",
      category: "me",
      categoryLabel: "Finance & Trading",
      days: [1, 2],
      datesText: "Oct 24 — 25",
      venue: "Finance Lab Simulation Terminals",
      format: "Algorithmic & Live Market Simulation",
      desc: "High-frequency stock market simulation trading real-time equities, commodities, and derivatives with fluctuating mock news.",
      prize: "₹30,000 Cash Prize"
    },
    {
      id: "chess",
      name: "Chess Grand Prix",
      category: "me",
      categoryLabel: "Mind Sports",
      days: [2],
      datesText: "Oct 25",
      venue: "Mind Hall (Quiet Pavilion)",
      format: "FIDE Swiss League (Rapid & Blitz)",
      desc: "FIDE-rated arbiters, digital DGT boards, and timed blitz tiebreaks to crown the collegiate Grandmaster.",
      prize: "₹20,000 + Grand Trophy"
    },
    {
      id: "esports",
      name: "Valorant & BGMI Cup",
      category: "me",
      categoryLabel: "Esports Arena",
      days: [3, 4],
      datesText: "Oct 26 — 27",
      venue: "Esports Booth & Discord War Room",
      format: "Custom Servers (BO3 Finals on Stage)",
      desc: "Live cast esports battles on big screens with dedicated shoutcasters, low-latency fibers, and spectator feeds.",
      prize: "₹40,000 + Gaming Gear"
    },
    {
      id: "fifa",
      name: "FIFA & EA Sports FC Arena",
      category: "me",
      categoryLabel: "Console Gaming",
      days: [1, 2],
      datesText: "Oct 24 — 25",
      venue: "Console Zone (Student Lounge)",
      format: "1v1 Bracket on PlayStation 5",
      desc: "Direct bracket knockouts with tournament controller settings, 6-minute halves, and competitive brackets.",
      prize: "₹15,000 + Gaming Headsets"
    },
    {
      id: "phoenix-awards",
      name: "Phoenix Award Ceremony",
      category: "cultural",
      categoryLabel: "Ceremony",
      days: [4],
      datesText: "Oct 27 (Evening)",
      venue: "Main Amphitheater",
      format: "Official Trophies & Valedictory",
      desc: "The grand valedictory ceremony honoring the Best Contingent, Fairplay Shield, and individual MVPs of Kurukshetra 2026.",
      prize: "Overall Phoenix Trophy"
    },
    {
      id: "star-night",
      name: "Celebrity Star Night",
      category: "cultural",
      categoryLabel: "Concert",
      days: [4],
      datesText: "Oct 27 (Night)",
      venue: "Main Festival Grounds",
      format: "Grand Festival Finale Concert",
      desc: "A massive music festival closing performance by headline Indian artists, pyrotechnics, and ceremonial extinguish of the flame.",
      prize: "Fest Finale Celebration"
    }
  ];

  // =========================================================================
  // 2. DOM ELEMENTS
  // =========================================================================
  const searchInput = document.getElementById('scheduleSearch');
  const clearBtn = document.getElementById('clearSearch');
  const catPills = document.querySelectorAll('.cat-pill');
  const dayTabBtns = document.querySelectorAll('.day-tab-btn');
  const dayCards = document.querySelectorAll('.day-card');
  const eventRows = document.querySelectorAll('.event-row');
  const emptyState = document.getElementById('emptyState');
  const resetSearchBtn = document.getElementById('resetSearchBtn');
  const indexList = document.getElementById('indexList');

  // Modal Elements
  const modalBackdrop = document.getElementById('eventModal');
  const modalClose = document.getElementById('modalClose');
  const modalCloseAction = document.getElementById('modalCloseAction');
  const modalCategory = document.getElementById('modalCategory');
  const modalName = document.getElementById('modalName');
  const modalDates = document.getElementById('modalDates');
  const modalVenue = document.getElementById('modalVenue');
  const modalFormat = document.getElementById('modalFormat');
  const modalPrize = document.getElementById('modalPrize');
  const modalDesc = document.getElementById('modalDesc');

  let activeCategory = 'all';
  let searchQuery = '';
  let activeDay = 'all';

  // =========================================================================
  // 3. RENDER MASTER INDEX DIRECTORY (Clean Minimalist At-A-Glance List)
  // =========================================================================
  function renderIndexDirectory() {
    if (!indexList) return;
    indexList.innerHTML = '';

    eventsDatabase.forEach(ev => {
      const item = document.createElement('div');
      item.className = 'index-item';
      item.setAttribute('data-id', ev.id);
      item.setAttribute('data-category', ev.category);

      const dotClass = ev.category === 'sports' ? 'dot-sports' : (ev.category === 'cultural' ? 'dot-cultural' : 'dot-me');

      item.innerHTML = `
        <span class="index-item-name">
          <span class="row-indicator ${dotClass}"></span>
          <span>${ev.name}</span>
        </span>
        <span class="index-item-dates">${ev.datesText}</span>
      `;
      indexList.appendChild(item);
    });
  }

  // =========================================================================
  // 4. UNIFIED FILTER & SEARCH LOGIC
  // =========================================================================
  function filterSchedule() {
    const q = searchQuery.toLowerCase().trim();
    let visibleCount = 0;

    // Filter event rows inside the 4 day cards
    eventRows.forEach(row => {
      const cat = row.getAttribute('data-category');
      const title = row.querySelector('.event-title').textContent.toLowerCase();

      const matchesCat = (activeCategory === 'all' || cat === activeCategory);
      const matchesSearch = (!q || title.includes(q));

      if (matchesCat && matchesSearch) {
        row.classList.remove('filtered-out');
        row.style.display = 'flex';
        visibleCount++;

        if (q && title.includes(q)) {
          row.classList.add('search-highlight');
        } else {
          row.classList.remove('search-highlight');
        }
      } else {
        row.classList.add('filtered-out');
        row.style.display = 'none';
        row.classList.remove('search-highlight');
      }
    });

    // Filter items in the index directory
    const indexItems = document.querySelectorAll('.index-item');
    indexItems.forEach(item => {
      const cat = item.getAttribute('data-category');
      const name = item.querySelector('.index-item-name span:nth-child(2)').textContent.toLowerCase();

      const matchesCat = (activeCategory === 'all' || cat === activeCategory);
      const matchesSearch = (!q || name.includes(q));

      item.style.display = (matchesCat && matchesSearch) ? 'flex' : 'none';
    });

    // Update column footer counters
    dayCards.forEach(card => {
      const visibleInCard = card.querySelectorAll('.event-row:not(.filtered-out)').length;
      const countEl = card.querySelector('.count-num');
      if (countEl) countEl.textContent = visibleInCard;
    });

    // Handle Empty State
    if (visibleCount === 0) {
      if (emptyState) emptyState.style.display = 'block';
    } else {
      if (emptyState) emptyState.style.display = 'none';
    }
  }

  // =========================================================================
  // 5. EVENT LISTENERS
  // =========================================================================

  // Search input
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      if (clearBtn) clearBtn.style.display = searchQuery.length > 0 ? 'inline-block' : 'none';
      filterSchedule();
    });
  }

  // Clear search button
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      clearBtn.style.display = 'none';
      filterSchedule();
      searchInput.focus();
    });
  }

  // Category Pills
  catPills.forEach(pill => {
    pill.addEventListener('click', () => {
      catPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeCategory = pill.getAttribute('data-category');
      filterSchedule();
    });
  });

  // Day Quick Selector Tabs (All Days vs Day 1/2/3/4)
  dayTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      dayTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      activeDay = btn.getAttribute('data-day');

      dayCards.forEach(card => {
        const cardDay = card.getAttribute('data-day');
        if (activeDay === 'all' || cardDay === activeDay) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // Reset Button in Empty State
  if (resetSearchBtn) {
    resetSearchBtn.addEventListener('click', () => {
      searchQuery = '';
      activeCategory = 'all';
      if (searchInput) searchInput.value = '';
      if (clearBtn) clearBtn.style.display = 'none';

      catPills.forEach(p => {
        if (p.getAttribute('data-category') === 'all') p.classList.add('active');
        else p.classList.remove('active');
      });

      filterSchedule();
    });
  }

  // =========================================================================
  // 6. QUICK MODAL DISPLAY (Refined & Minimalist)
  // =========================================================================
  function openModal(id) {
    const event = eventsDatabase.find(e => e.id === id);
    if (!event) return;

    if (modalCategory) modalCategory.textContent = event.categoryLabel.toUpperCase();
    if (modalName) modalName.textContent = event.name;
    if (modalVenue) modalVenue.textContent = event.venue;
    if (modalFormat) modalFormat.textContent = event.format;
    if (modalPrize) modalPrize.textContent = event.prize;
    if (modalDesc) modalDesc.textContent = event.desc;

    if (modalDates) {
      modalDates.innerHTML = '';
      const dayNames = ["Oct 24 (Thu)", "Oct 25 (Fri)", "Oct 26 (Sat)", "Oct 27 (Sun)"];
      [1, 2, 3, 4].forEach(d => {
        const span = document.createElement('span');
        const isActive = event.days.includes(d);
        span.className = `modal-date-chip ${isActive ? 'active' : ''}`;
        span.textContent = `${isActive ? '● ' : ''}Day 0${d}: ${dayNames[d-1]}`;
        modalDates.appendChild(span);
      });
    }

    if (modalBackdrop) {
      modalBackdrop.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal() {
    if (modalBackdrop) {
      modalBackdrop.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  // Click delegation for all event triggers (day rows and index rows)
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('.event-row, .index-item');
    if (trigger) {
      const id = trigger.getAttribute('data-id');
      if (id) {
        e.preventDefault();
        openModal(id);
      }
    }
  });

  if (modalClose) modalClose.addEventListener('click', closeModal);
  if (modalCloseAction) modalCloseAction.addEventListener('click', closeModal);
  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalBackdrop && modalBackdrop.style.display === 'flex') {
      closeModal();
    }
  });

  // Mobile menu toggle
  const mobileToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      const isVisible = navLinks.style.display === 'flex';
      navLinks.style.display = isVisible ? 'none' : 'flex';
      if (!isVisible) {
        navLinks.style.flexDirection = 'column';
        navLinks.style.position = 'absolute';
        navLinks.style.top = '58px';
        navLinks.style.left = '0';
        navLinks.style.width = '100%';
        navLinks.style.background = '#FFFFFF';
        navLinks.style.borderRadius = '16px';
        navLinks.style.padding = '16px';
        navLinks.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
        navLinks.style.border = '1px solid rgba(0,0,0,0.08)';
      }
    });
  }

  // =========================================================================
  // 7. INITIALIZE
  // =========================================================================
  renderIndexDirectory();
  filterSchedule();

});
