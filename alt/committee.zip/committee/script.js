/**
 * FLAME Kurukshetra 2026 / 2027 - Official Committee Heads
 * Includes Chairperson, 2 General Secretaries, and the 14 Core Committee Heads.
 * Clean, Smooth, Modern & Unified layout with fun, professional animations.
 */

const committeeData = [
  // ==========================================
  // APEX LEADERSHIP
  // ==========================================
  {
    id: "HEAD-01",
    name: "Chairperson",
    role: "Chairperson",
    wing: "governance",
    photo: "assets/heads/ec-president.jpg",
    idBadge: "🔥 CHAIRPERSON",
    oneLiner: "Steering overarching institutional alignment, festival strategy, and apex leadership for Kurukshetra.",
    wingLabel: "Apex Leadership",
    roleClass: "role-ec",
    instagram: "flamekurukshetra",
    fullBio: "The Chairperson steers the overarching festival vision, University Senate liaison, and council execution matrix. Ensuring Kurukshetra sets new benchmarks across athletic integrity, production grandeur, and nationwide contingent participation.",
    deliverables: [
      "Strategic university governance & institutional clearances",
      "Inter-collegiate council leadership & steering protocols",
      "Festival milestone roadmaps & apex steering committee oversight"
    ],
    email: "chairperson.kurukshetra@flame.edu.in",
    linkedin: "https://linkedin.com"
  },
  {
    id: "HEAD-02",
    name: "General Secretary",
    role: "General Secretary",
    wing: "governance",
    photo: "assets/heads/ec-vice-president.jpg",
    idBadge: "✨ GENERAL SECRETARY",
    oneLiner: "Orchestrating council administration, inter-university delegations, and multi-wing operational convergence.",
    wingLabel: "Central Administration",
    roleClass: "role-ec",
    instagram: "flamekurukshetra",
    fullBio: "Coordinates strategic convergence across all festival operational wings. The mandate encompasses contingent growth roadmaps, institutional alliances, and dispute-resolution frameworks to maintain seamless cross-department synchrony.",
    deliverables: [
      "Contingent delegation expansion across 60+ Tier-1 universities",
      "Cross-wing synchronization & conflict mitigation matrices",
      "Daily operational execution reviews and milestone tracking"
    ],
    email: "gensec1.kurukshetra@flame.edu.in",
    linkedin: "https://linkedin.com"
  },
  {
    id: "HEAD-03",
    name: "General Secretary",
    role: "General Secretary",
    wing: "governance",
    photo: "assets/heads/ec-secretary.jpg",
    idBadge: "📋 GENERAL SECRETARY",
    oneLiner: "Managing regulatory compliance, senate approvals, and grievance resolution frameworks across contingents.",
    wingLabel: "Council Protocol",
    roleClass: "role-ec",
    instagram: "flamekurukshetra",
    fullBio: "Oversees festival protocol, official communications, regulatory compliance, and university administrative alignment. Serves as the primary custodian of festival governance and contingent grievance resolutions.",
    deliverables: [
      "Official University Council approvals & contingent rulebook",
      "Festival documentation, judicial committee & contingent accreditation",
      "Central dispatch and daily festival communications bulletin"
    ],
    email: "gensec2.kurukshetra@flame.edu.in",
    linkedin: "https://linkedin.com"
  },

  // ==========================================
  // COMMITTEE HEADS (From Official Roster)
  // ==========================================
  {
    id: "HEAD-04",
    name: "Divyanshri Munot",
    role: "Head of Admin & Logistics",
    wing: "logistics",
    photo: "assets/heads/cc-logistics.jpg",
    idBadge: "⚡ ADMIN & LOGISTICS",
    oneLiner: "Commanding heavy arena equipment staging, multi-arena transport flow, and round-the-clock logistics.",
    wingLabel: "Admin & Logistics",
    roleClass: "role-ops",
    instagram: "divyanshri_munot",
    fullBio: "Divyanshri oversees the backbone of Kurukshetra, managing venue fabrication, stadium equipment, equipment transfers, electrical matrices, and uninterrupted vendor coordination across all 4 festival days.",
    deliverables: [
      "Venue fabrication, arena staging & heavy equipment procurement",
      "Round-the-clock logistics supply chains & diesel generators",
      "Court-side equipment readiness & tournament gear allocation"
    ],
    email: "divyanshri.munot@flame.edu.in",
    linkedin: "https://instagram.com/divyanshri_munot"
  },
  {
    id: "HEAD-05",
    name: "Sid Shekhar",
    role: "Head of Hospitality",
    wing: "hospitality",
    photo: "assets/heads/cc-hospitality.jpg",
    idBadge: "🏨 HOSPITALITY",
    oneLiner: "Facilitating luxury athlete lodging, nutrition dining pipelines, and dedicated concierges for 2,000+ participants.",
    wingLabel: "Hospitality & VIP",
    roleClass: "role-pr",
    instagram: "_sidshekhar_",
    fullBio: "Sid leads the hospitality brigade, guaranteeing comfortable accommodations, curated athlete nutrition, transit shuttles, and VIP protocol for hundreds of visiting contingents and celebrity guests.",
    deliverables: [
      "Athlete accommodation allotment across partnered luxury hotels",
      "High-nutrition catering, hydration zones & dining pipelines",
      "24/7 contingent concierge desk & transit shuttle fleet management"
    ],
    email: "sid.shekhar@flame.edu.in",
    linkedin: "https://instagram.com/_sidshekhar_"
  },
  {
    id: "HEAD-06",
    name: "Mishti Gupta",
    role: "Co-Head PR",
    wing: "pr",
    photo: "assets/heads/cc-marketing.jpg",
    idBadge: "📢 CO-HEAD PR",
    oneLiner: "Spearheading national press outreach, external media relations, and public communications across university networks.",
    wingLabel: "PR & Media",
    roleClass: "role-creative",
    instagram: "mishtigupta_",
    fullBio: "Mishti drives national media coverage, print publications, news wire syndications, and high-visibility festival press briefings, elevating Kurukshetra's identity as a premier collegiate brand.",
    deliverables: [
      "National press releases, journalist accreditation & festival media kit",
      "Strategic PR alliances with national collegiate publications",
      "Crisis communication management and external brand messaging"
    ],
    email: "mishti.gupta@flame.edu.in",
    linkedin: "https://instagram.com/mishtigupta_"
  },
  {
    id: "HEAD-07",
    name: "Yashasvi Nagarale",
    role: "Co-Head PR",
    wing: "pr",
    photo: "assets/heads/ec-corporate.jpg",
    idBadge: "📢 CO-HEAD PR",
    oneLiner: "Driving campus ambassador syndications, influencer tie-ups, and student PR networks across 60+ universities.",
    wingLabel: "PR & Media",
    roleClass: "role-creative",
    instagram: "yashasvinagarale_",
    fullBio: "Yashasvi coordinates extensive student outreach across colleges, managing national campus ambassadors, digital press campaigns, and celebrity engagement.",
    deliverables: [
      "National Campus Ambassador network spanning 60+ partner campuses",
      "Influencer collaborations, podcast interviews & festival buzz",
      "On-ground press desk and athlete spotlight interviews"
    ],
    email: "yashasvi.nagarale@flame.edu.in",
    linkedin: "https://instagram.com/yashasvinagarale_"
  },
  {
    id: "HEAD-08",
    name: "Saanvi Agrawal",
    role: "Head of Sports",
    wing: "sports",
    photo: "assets/heads/ec-operations.jpg",
    idBadge: "🏆 SPORTS",
    oneLiner: "Administering national tournament fixtures, rulebook compliance, certified referee panels, and podium tallies.",
    wingLabel: "Sports Operations",
    roleClass: "role-sports",
    instagram: "saanvii_agrawal",
    fullBio: "Saanvi commands the flagship sporting tournaments of Kurukshetra, governing 12+ national athletic disciplines, international standard court fixtures, and federation-certified referee adjudications.",
    deliverables: [
      "Fixtures across Turf Football, Basketball, Tennis, Cricket, Badminton & Track",
      "Federation-certified referee panels & judicial dispute committee",
      "Real-time match schedules, point tables & championship trophies"
    ],
    email: "saanvi.agrawal@flame.edu.in",
    linkedin: "https://instagram.com/saanvii_agrawal"
  },
  {
    id: "HEAD-09",
    name: "Anvi",
    role: "Co-Head Culturals",
    wing: "cultural",
    photo: "assets/heads/cc-cultural.jpg",
    idBadge: "🎭 CO-HEAD CULTURALS",
    oneLiner: "Curating Kalakaar Katta, headline musical acts, stage spectacles, and immersive amphitheater productions.",
    wingLabel: "Cultural & Stage",
    roleClass: "role-cultural",
    instagram: "_.anviii._",
    fullBio: "Anvi shapes the vibrant cultural heart of Kurukshetra, spearheading Kalakaar Katta, concert lighting, theatrical sets, and star artist nights that illuminate the FLAME amphitheater.",
    deliverables: [
      "Curating Kalakaar Katta flagship showcase & stage choreography",
      "A-list celebrity artist contracting, sound checks & rider hospitality",
      "Stage aesthetics, dynamic light cues & stadium spectacle timing"
    ],
    email: "anvi@flame.edu.in",
    linkedin: "https://instagram.com/_.anviii._"
  },
  {
    id: "HEAD-10",
    name: "Dhritee",
    role: "Co-Head Culturals",
    wing: "cultural",
    photo: "assets/heads/cc-creatives.jpg",
    idBadge: "🎭 CO-HEAD CULTURALS",
    oneLiner: "Directing battle of the bands, street dance battles, acoustic showcases, and high-energy festival stages.",
    wingLabel: "Cultural & Stage",
    roleClass: "role-cultural",
    instagram: "dhritee_bee",
    fullBio: "Dhritee leads competitive cultural showcases, overseeing band showdowns, rap cyphers, street dance arenas, and interactive performing arts competitions with renowned judges.",
    deliverables: [
      "Battle of the Bands, Step Up Dance, and Slam Poetry rulebooks",
      "Judge panels consisting of industry stalwarts and music producers",
      "Acoustic setups, sound mixing & audience experience design"
    ],
    email: "dhritee@flame.edu.in",
    linkedin: "https://instagram.com/dhritee_bee"
  },
  {
    id: "HEAD-11",
    name: "Ayush Mittal",
    role: "Head of Management Events",
    wing: "management",
    photo: "assets/heads/cc-esports.jpg",
    idBadge: "💼 MANAGEMENT EVENTS",
    oneLiner: "Orchestrating Shark Arena B-Plan pitches, corporate crisis simulations, stock trading floors, and case studies.",
    wingLabel: "Management Events",
    roleClass: "role-tech",
    instagram: "ayush.mittalll",
    fullBio: "Ayush commands the intellectual arena of Kurukshetra, staging high-stakes venture pitching, simulated stock markets, crisis response rooms, and live business strategy faceoffs with venture capitalists.",
    deliverables: [
      "Shark Arena B-Plan competition with active VC angel investors",
      "Wolf of Dalal Street real-time trading floor simulation",
      "Corporate crisis simulation rooms & business consulting cases"
    ],
    email: "ayush.mittal@flame.edu.in",
    linkedin: "https://instagram.com/ayush.mittalll"
  },
  {
    id: "HEAD-12",
    name: "Devam Gadia",
    role: "Head of Finance",
    wing: "finance",
    photo: "assets/heads/ec-finance.jpg",
    idBadge: "💎 FINANCE",
    oneLiner: "Steward of multi-crore budget modeling, cash disbursements, sponsor auditing, and treasury compliance.",
    wingLabel: "Finance & Accounts",
    roleClass: "role-ec",
    instagram: "devam.gadia",
    fullBio: "Devam manages the festival treasury, overseeing commercial agreements, vendor disbursement milestones, prize pool allocations, and meticulous audit transparency.",
    deliverables: [
      "Festival multi-crore operating budget modeling & cash-flow planning",
      "Vendor invoice clearance, prize pool escrow & tax compliance",
      "Daily expenditure auditing and post-fest fiscal closure reports"
    ],
    email: "devam.gadia@flame.edu.in",
    linkedin: "https://instagram.com/devam.gadia"
  },
  {
    id: "HEAD-13",
    name: "Shashwat",
    role: "Head of Sponsorship",
    wing: "sponsorship",
    photo: "assets/heads/cc-sponsorship.jpg",
    idBadge: "🎯 SPONSORSHIP",
    oneLiner: "Securing tier-1 corporate brand deals, marquee title partnerships, on-court activations, and sponsor ROI.",
    wingLabel: "Sponsorship & Alliances",
    roleClass: "role-pr",
    instagram: "shashwat_1702",
    fullBio: "Shashwat leads corporate alliance development, pitching national brands, negotiating title endorsements, organizing experiential marketing booths, and optimizing sponsor brand equity.",
    deliverables: [
      "Title, Associate, and Beverage marquee brand sponsorships",
      "30+ promotional stalls, product sampling zones & sponsor lounges",
      "Corporate analytics reporting and guaranteed sponsor deliverables"
    ],
    email: "shashwat@flame.edu.in",
    linkedin: "https://instagram.com/shashwat_1702"
  },
  {
    id: "HEAD-14",
    name: "Janhavi",
    role: "Head of Registrations",
    wing: "registrations",
    photo: "assets/heads/cc-sports.jpg",
    idBadge: "📝 REGISTRATIONS",
    oneLiner: "Supervising 2,500+ athlete sign-ups, team accreditation badges, slot allotment, and contingent check-ins.",
    wingLabel: "Contingent Registrations",
    roleClass: "role-sports",
    instagram: "janhavi.1010",
    fullBio: "Janhavi runs the registration pipeline, overseeing collegiate verification, athlete digital credentials, slot allocation, and real-time contingent reception upon campus arrival.",
    deliverables: [
      "Contingent registration portal administration & KYC validation",
      "Athlete credential cards, security wristbands & event badges",
      "Real-time contingent desk for on-the-spot team slotting"
    ],
    email: "janhavi@flame.edu.in",
    linkedin: "https://instagram.com/janhavi.1010"
  },
  {
    id: "HEAD-15",
    name: "Stuti Lakshman",
    role: "Head of Ceremonies",
    wing: "ceremonies",
    photo: "assets/heads/cc-ceremonies.jpg",
    idBadge: "✨ CEREMONIES",
    oneLiner: "Choreographing the opening torchbearer parade, stadium medal podiums, and grand closing spectacles.",
    wingLabel: "Ceremonies & Protocols",
    roleClass: "role-cultural",
    instagram: "stuti_lakshman",
    fullBio: "Stuti directs the monumental ceremonial moments of Kurukshetra, including the Phoenix flame lighting, captain oath-taking marches, grand medal ceremonies, and fireworks finales.",
    deliverables: [
      "Opening Ceremony choreography, contingent parade & Phoenix torch flame",
      "Medal distribution protocol, dignitary felicitation & podium ceremonies",
      "Closing Ceremony spectacle and trophy presentation choreography"
    ],
    email: "stuti.lakshman@flame.edu.in",
    linkedin: "https://instagram.com/stuti_lakshman"
  },
  {
    id: "HEAD-16",
    name: "Nischal Jogani",
    role: "Head of IT",
    wing: "it",
    photo: "assets/heads/cc-tech.jpg",
    idBadge: "💻 IT & DIGITAL",
    oneLiner: "Engineering low-latency web portals, sub-second live scoreboards, API scoring feeds, and campus mesh Wi-Fi.",
    wingLabel: "IT & Digital Grid",
    roleClass: "role-tech",
    instagram: "nischaljogani",
    fullBio: "Nischal commands the digital architecture of Kurukshetra, deploying web registration portals, real-time match scoring APIs, live stream integrations, and robust network infrastructure.",
    deliverables: [
      "Festival web architecture, contingent authentication & live schedule API",
      "Court-side referee digital scoring pads with instant arena board sync",
      "High-bandwidth Wi-Fi meshes across turfs, arenas & press rooms"
    ],
    email: "nischal.jogani@flame.edu.in",
    linkedin: "https://instagram.com/nischaljogani"
  },
  {
    id: "HEAD-17",
    name: "Rajveer",
    role: "Head of Security",
    wing: "security",
    photo: "assets/heads/cc-security.jpg",
    idBadge: "🛡️ SECURITY",
    oneLiner: "Managing 24/7 stadium access checkpoints, paramedic emergency lanes, and zero-incident festival safety.",
    wingLabel: "Security & Crowd Safety",
    roleClass: "role-ops",
    instagram: "hennessy_rajveer5",
    fullBio: "Rajveer ensures the safety of over 15,000 daily campus footfalls, coordinating access points, emergency medical lanes, crowd flow dynamics, and rapid-response safety dispatches.",
    deliverables: [
      "24/7 stadium security perimeters, metal detectors & access control",
      "Paramedic emergency stations, doctors on standby & ambulance lanes",
      "Crowd control protocols during high-intensity football & concert nights"
    ],
    email: "rajveer@flame.edu.in",
    linkedin: "https://instagram.com/hennessy_rajveer5"
  }
];

// DOM Elements
const committeeGrid = document.getElementById("committeeGrid");
const noResultsState = document.getElementById("noResultsState");
const searchInput = document.getElementById("committeeSearch");
const wingTags = document.querySelectorAll(".wing-tag");
const displayedCountElem = document.getElementById("displayedCount");
const totalCountElem = document.getElementById("totalCount");

// Modal Elements
const profileModal = document.getElementById("profileModal");
const modalCloseBtn = document.getElementById("modalCloseBtn");
const modalPhoto = document.getElementById("modalPhoto");
const modalId = document.getElementById("modalId");
const modalName = document.getElementById("modalName");
const modalRole = document.getElementById("modalRole");
const modalBio = document.getElementById("modalBio");
const modalDeliverables = document.getElementById("modalDeliverables");
const modalMetaDept = document.getElementById("modalMetaDept");
const modalEmailLink = document.getElementById("modalEmailLink");
const modalLinkedInLink = document.getElementById("modalLinkedInLink");

// Current Filter State
let currentWing = "all";
let searchQuery = "";

// Render Cards
function renderCards() {
  const filtered = committeeData.filter(head => {
    const wingMatch = (currentWing === "all") || (head.wing === currentWing);
    
    const q = searchQuery.toLowerCase().trim();
    const searchMatch = !q || (
      head.name.toLowerCase().includes(q) ||
      head.role.toLowerCase().includes(q) ||
      head.oneLiner.toLowerCase().includes(q) ||
      head.wingLabel.toLowerCase().includes(q) ||
      head.idBadge.toLowerCase().includes(q) ||
      (head.instagram && head.instagram.toLowerCase().includes(q))
    );

    return wingMatch && searchMatch;
  });

  if (displayedCountElem) displayedCountElem.textContent = filtered.length;
  if (totalCountElem) totalCountElem.textContent = committeeData.length;

  if (filtered.length === 0) {
    committeeGrid.innerHTML = "";
    noResultsState.style.display = "block";
    return;
  }

  noResultsState.style.display = "none";

  const cardsHtml = filtered.map(head => {
    return `
      <div class="committee-card" data-id="${head.id}" onclick="openDossier('${head.id}')">
        <!-- Smooth Portrait Capsule -->
        <div class="card-portrait-wrap">
          <div class="card-top-pill">
            <span class="pill-glow-dot"></span>
            <span>${head.idBadge}</span>
          </div>
          <img src="${head.photo}" alt="${head.name} - ${head.role}" class="head-portrait-img" loading="lazy">
          <div class="portrait-vignette"></div>
        </div>

        <!-- Clean Card Content -->
        <div class="card-content-area">
          <h3 class="card-person-name">${head.name}</h3>
          <div class="card-role-title ${head.roleClass}">
            ${head.role}
          </div>
          <p class="card-one-liner">${head.oneLiner}</p>

          <!-- Bottom Capsule Row: Soft Tag + Interactive Action Pill -->
          <div class="card-bottom-row">
            <span class="bottom-wing-pill">${head.wingLabel}</span>
            <button class="btn-view-profile-pill" type="button" aria-label="View profile of ${head.name}">
              <span>View Bio</span>
              <span class="arrow-icon">→</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  committeeGrid.innerHTML = cardsHtml;
}

// Open Profile Dossier Modal
window.openDossier = function(id) {
  const head = committeeData.find(item => item.id === id);
  if (!head) return;

  modalPhoto.src = head.photo;
  modalPhoto.alt = head.name;
  modalId.textContent = head.idBadge;
  modalName.textContent = head.name;
  modalRole.textContent = head.role;
  modalBio.textContent = head.fullBio;
  
  modalDeliverables.innerHTML = head.deliverables.map(del => `<li>${del}</li>`).join("");
  modalMetaDept.textContent = `${head.wingLabel} // COMMITTEE HEAD`;
  
  modalEmailLink.href = `mailto:${head.email}`;
  
  // Instagram / LinkedIn Link
  if (head.instagram && head.instagram !== "flamekurukshetra") {
    modalLinkedInLink.href = `https://instagram.com/${head.instagram}`;
    modalLinkedInLink.innerHTML = `<span>📸</span> @${head.instagram}`;
  } else {
    modalLinkedInLink.href = `https://instagram.com/flamekurukshetra`;
    modalLinkedInLink.innerHTML = `<span>📸</span> @flamekurukshetra`;
  }

  profileModal.classList.add("active");
  document.body.style.overflow = "hidden";
};

// Close Profile Dossier Modal
function closeDossier() {
  profileModal.classList.remove("active");
  document.body.style.overflow = "";
}

// Event Listeners
function initEventListeners() {
  wingTags.forEach(tag => {
    tag.addEventListener("click", () => {
      wingTags.forEach(t => t.classList.remove("active"));
      tag.classList.add("active");
      currentWing = tag.getAttribute("data-wing");
      renderCards();
    });
  });

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      searchQuery = e.target.value;
      renderCards();
    });
  }

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener("click", closeDossier);
  }

  if (profileModal) {
    profileModal.addEventListener("click", (e) => {
      if (e.target === profileModal) {
        closeDossier();
      }
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && profileModal.classList.contains("active")) {
      closeDossier();
    }
    if (e.key === "/" && document.activeElement !== searchInput) {
      e.preventDefault();
      searchInput.focus();
    }
  });

  const mobileToggle = document.querySelector(".mobile-menu-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener("click", () => {
      const isVisible = navLinks.style.display === "flex";
      navLinks.style.display = isVisible ? "none" : "flex";
      if (!isVisible) {
        navLinks.style.flexDirection = "column";
        navLinks.style.position = "absolute";
        navLinks.style.top = "100%";
        navLinks.style.left = "0";
        navLinks.style.width = "100%";
        navLinks.style.background = "#0e1118";
        navLinks.style.padding = "20px";
        navLinks.style.borderRadius = "20px";
        navLinks.style.marginTop = "10px";
        navLinks.style.border = "1px solid rgba(254, 90, 0, 0.3)";
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  renderCards();
  initEventListeners();
});
