/**
 * FLAME KURUKSHETRA 2026 - OFFICIAL ALBUM & GOOGLE DRIVE ARCHIVE
 * 3D Rotating Album On Axis + Crystal Phoenix Shatter Engine + Google Drive Layout
 */

// ==========================================================================
// 1. DATA STORE: DAY-WISE KURUKSHETRA SPORTS ARCHIVE
// ==========================================================================
const ARCHIVE_DATA = {
  days: [
    {
      id: "day1",
      name: "Day 01 - Torch Run, Opening & Football",
      date: "Oct 18, 2026",
      shortTitle: "Day 01: The Spark & Kickoff",
      itemCount: 8,
      size: "480 MB",
      folderDesc: "Opening ceremonies, flame lighting torch relay, and round 1 men's & women's football matches on the central turf.",
      photos: [
        {
          id: "d1_01",
          dayId: "day1",
          title: "KURU26_D1_TORCH_LIGHTING_4K.JPG",
          sport: "Ceremonies",
          venue: "FLAME Central Amphitheater",
          size: "5.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Aarav Sharma (FLAME Media)",
          exif: "Sony A7 IV • 24-70mm GM • f/2.8 • 1/1250s • ISO 200",
          image: "assets/collage-cheer.png",
          starred: true,
          matchInfo: "Sacred Phoenix flame ignited by University Chancellor & Sports Captains."
        },
        {
          id: "d1_02",
          dayId: "day1",
          title: "KURU26_D1_FOOTBALL_STRIKE_GOAL.JPG",
          sport: "Football",
          venue: "Main Turf Football Stadium",
          size: "6.2 MB",
          dimensions: "4096 x 2304",
          photographer: "Rohan Varma (Flame Creatives)",
          exif: "Sony A1 • 70-200mm f/2.8 GM II • f/2.8 • 1/2500s • ISO 400",
          image: "assets/hero-player.png",
          starred: true,
          matchInfo: "FLAME Strikers vs Ashoka Knights (3 - 1) • 88th minute volley."
        },
        {
          id: "d1_03",
          dayId: "day1",
          title: "KURU26_D1_CENTRAL_TURF_PITCH_AERIAL.JPG",
          sport: "Football",
          venue: "North Turf Arena",
          size: "4.9 MB",
          dimensions: "3840 x 2160",
          photographer: "Priya Nair",
          exif: "DJI Inspire 3 • 24mm • f/4.0 • 1/800s • ISO 100",
          image: "assets/bento-court.png",
          starred: false,
          matchInfo: "Opening match contingent line-up before national anthem."
        },
        {
          id: "d1_04",
          dayId: "day1",
          title: "KURU26_D1_CONTINGENT_MARCH_PAST.JPG",
          sport: "Ceremonies",
          venue: "Olympic Track Oval",
          size: "5.1 MB",
          dimensions: "3840 x 2160",
          photographer: "Karan Johar (Media Council)",
          exif: "Canon EOS R5 • 50mm f/1.2 • f/2.0 • 1/2000s • ISO 160",
          image: "assets/hero-avatars.png",
          starred: false,
          matchInfo: "Athletes parade from 42 colleges across India."
        },
        {
          id: "d1_05",
          dayId: "day1",
          title: "KURU26_D1_MIDFIELD_TACKLE_DRAMA.JPG",
          sport: "Football",
          venue: "Main Turf Football Stadium",
          size: "5.6 MB",
          dimensions: "3840 x 2160",
          photographer: "Rohan Varma",
          exif: "Sony A7 IV • 135mm f/1.8 GM • f/2.0 • 1/3200s • ISO 250",
          image: "assets/jumping-player.png",
          starred: true,
          matchInfo: "Crucial sliding challenge in Group A quarter clash."
        },
        {
          id: "d1_06",
          dayId: "day1",
          title: "KURU26_D1_PHOENIX_TROPHY_REVEAL.JPG",
          sport: "Ceremonies",
          venue: "Indoor Auditorium",
          size: "7.1 MB",
          dimensions: "4000 x 3000",
          photographer: "Aarav Sharma",
          exif: "Fujifilm GFX 100S • 32-64mm • f/4 • 1/500s • ISO 100",
          image: "assets/phoenix-web.png",
          starred: true,
          matchInfo: "The solid bronze Kurukshetra Phoenix Trophy unveiled."
        },
        {
          id: "d1_07",
          dayId: "day1",
          title: "KURU26_D1_FANS_ROAR_STANDS.JPG",
          sport: "Crowd & Vibes",
          venue: "East Stands Arena",
          size: "4.4 MB",
          dimensions: "3840 x 2160",
          photographer: "Ananya Sen",
          exif: "Sony A7 III • 35mm f/1.4 • f/1.8 • 1/1600s • ISO 320",
          image: "assets/collage-cheer.png",
          starred: false,
          matchInfo: "1,800 students chanting in the opening kickoff clash."
        },
        {
          id: "d1_08",
          dayId: "day1",
          title: "KURU26_D1_GOALPOST_CELEBRATION.JPG",
          sport: "Football",
          venue: "Main Turf Football Stadium",
          size: "6.0 MB",
          dimensions: "3840 x 2160",
          photographer: "Rohan Varma",
          exif: "Sony A1 • 70-200mm • f/2.8 • 1/2500s • ISO 320",
          image: "assets/hero-player.png",
          starred: false,
          matchInfo: "FLAME team rushing to celebrate stoppage-time winner."
        }
      ]
    },
    {
      id: "day2",
      name: "Day 02 - Basketball, Badminton & Tennis",
      date: "Oct 19, 2026",
      shortTitle: "Day 02: Court Battles & Intensity",
      itemCount: 8,
      size: "620 MB",
      folderDesc: "High-octane court showdowns: Basketball buzzer beaters, Lawn tennis aces, and lightning fast Badminton smash rallies.",
      photos: [
        {
          id: "d2_01",
          dayId: "day2",
          title: "KURU26_D2_BASKETBALL_SLAM_DUNK.JPG",
          sport: "Basketball",
          venue: "Indoor Hardwood Arena",
          size: "6.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Vikram Malhotra (Media Council)",
          exif: "Nikon Z9 • 70-200mm f/2.8 • f/2.8 • 1/2000s • ISO 800",
          image: "assets/how-it-works-player.png",
          starred: true,
          matchInfo: "Sky-high rim jam in semi-final clash FLAME vs Christ Univ."
        },
        {
          id: "d2_02",
          dayId: "day2",
          title: "KURU26_D2_TENNIS_SERVE_ACE_4K.JPG",
          sport: "Tennis",
          venue: "Synthetic Championship Courts",
          size: "6.4 MB",
          dimensions: "4096 x 2304",
          photographer: "Priya Nair",
          exif: "Sony A1 • 100-400mm GM • f/4.5 • 1/3200s • ISO 200",
          image: "assets/bento-player-serve.png",
          starred: true,
          matchInfo: "185 km/h kick serve ace in singles quarters."
        },
        {
          id: "d2_03",
          dayId: "day2",
          title: "KURU26_D2_COURT_RIM_DRAMA.JPG",
          sport: "Basketball",
          venue: "Outdoor Floodlit Court",
          size: "4.7 MB",
          dimensions: "3840 x 2160",
          photographer: "Vikram Malhotra",
          exif: "Sony A7 IV • 24-70mm • f/2.8 • 1/1600s • ISO 400",
          image: "assets/cta-court.png",
          starred: false,
          matchInfo: "Game-winning fadeaway 3-pointer buzzer beater."
        },
        {
          id: "d2_04",
          dayId: "day2",
          title: "KURU26_D2_BADMINTON_SHUTTLE_SMASH.JPG",
          sport: "Badminton",
          venue: "Indoor Wooden Badminton Complex",
          size: "5.5 MB",
          dimensions: "3840 x 2160",
          photographer: "Aarav Sharma",
          exif: "Canon R3 • 85mm f/1.2 • f/1.8 • 1/2500s • ISO 640",
          image: "assets/card-racket.png",
          starred: true,
          matchInfo: "Mid-air smash clocked at 340 km/h in Men's Singles."
        },
        {
          id: "d2_05",
          dayId: "day2",
          title: "KURU26_D2_BENCH_CELEBRATION_DRAMA.JPG",
          sport: "Basketball",
          venue: "Indoor Hardwood Arena",
          size: "5.1 MB",
          dimensions: "3840 x 2160",
          photographer: "Ananya Sen",
          exif: "Sony A7 III • 35mm • f/2.0 • 1/1250s • ISO 500",
          image: "assets/collage-cheer.png",
          starred: false,
          matchInfo: "Bench clearing celebration after thrilling overtime victory."
        },
        {
          id: "d2_06",
          dayId: "day2",
          title: "KURU26_D2_TENNIS_BACKHAND_SLICE.JPG",
          sport: "Tennis",
          venue: "Championship Court 2",
          size: "5.9 MB",
          dimensions: "3840 x 2160",
          photographer: "Priya Nair",
          exif: "Sony A7 IV • 70-200mm • f/2.8 • 1/2500s • ISO 250",
          image: "assets/pill-player.png",
          starred: false,
          matchInfo: "Precise drop shot slice down the line in Women's Singles."
        },
        {
          id: "d2_07",
          dayId: "day2",
          title: "KURU26_D2_BADMINTON_RACKET_ACTION.JPG",
          sport: "Badminton",
          venue: "Indoor Wooden Complex",
          size: "4.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Aarav Sharma",
          exif: "Canon R5 • 50mm • f/2.2 • 1/2000s • ISO 400",
          image: "assets/pill-racket.png",
          starred: false,
          matchInfo: "Dynamic doubles coordination in quarterfinals."
        },
        {
          id: "d2_08",
          dayId: "day2",
          title: "KURU26_D2_COACH_TACTICS_TIMEOUT.JPG",
          sport: "Basketball",
          venue: "Indoor Hardwood Arena",
          size: "5.3 MB",
          dimensions: "3840 x 2160",
          photographer: "Vikram Malhotra",
          exif: "Nikon Z9 • 24-70mm • f/2.8 • 1/1000s • ISO 640",
          image: "assets/hero-avatars.png",
          starred: false,
          matchInfo: "High-pressure tactical huddle with 14 seconds on the shot clock."
        }
      ]
    },
    {
      id: "day3",
      name: "Day 03 - Track, Athletics & Volleyball",
      date: "Oct 20, 2026",
      shortTitle: "Day 03: Speed, Leaps & Semifinals",
      itemCount: 8,
      size: "710 MB",
      folderDesc: "The pursuit of gold: 100m sprint photo-finishes, 4x100m relays, high jump records, and volleyball spikes.",
      photos: [
        {
          id: "d3_01",
          dayId: "day3",
          title: "KURU26_D3_100M_SPRINT_FINISH_LINE.JPG",
          sport: "Athletics",
          venue: "Synthetic 8-Lane Track",
          size: "6.9 MB",
          dimensions: "3840 x 2160",
          photographer: "Kabir Mehta (FLAME Media)",
          exif: "Sony A1 • 70-200mm f/2.8 GM • f/2.8 • 1/4000s • ISO 160",
          image: "assets/collage-run.png",
          starred: true,
          matchInfo: "New intercollegiate meet record 10.38 seconds!"
        },
        {
          id: "d3_02",
          dayId: "day3",
          title: "KURU26_D3_VOLLEYBALL_NET_SPIKE.JPG",
          sport: "Volleyball",
          venue: "Sand Arena & Hard Court",
          size: "6.1 MB",
          dimensions: "4096 x 2304",
          photographer: "Priya Nair",
          exif: "Nikon Z9 • 70-200mm • f/2.8 • 1/2500s • ISO 400",
          image: "assets/faq-player.png",
          starred: true,
          matchInfo: "Monster block and downward spike in semifinal tiebreaker."
        },
        {
          id: "d3_03",
          dayId: "day3",
          title: "KURU26_D3_HIGH_JUMP_CLEARANCE.JPG",
          sport: "Athletics",
          venue: "Field Events Sector B",
          size: "5.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Kabir Mehta",
          exif: "Sony A7 IV • 135mm f/1.8 • f/2.0 • 1/3200s • ISO 200",
          image: "assets/jumping-player.png",
          starred: true,
          matchInfo: "Clearing 2.08m bar on the final attempt."
        },
        {
          id: "d3_04",
          dayId: "day3",
          title: "KURU26_D3_4X100_BATON_EXCHANGE.JPG",
          sport: "Athletics",
          venue: "Synthetic 8-Lane Track",
          size: "5.4 MB",
          dimensions: "3840 x 2160",
          photographer: "Rohan Varma",
          exif: "Canon R5 • 70-200mm • f/2.8 • 1/2500s • ISO 200",
          image: "assets/collage-run.png",
          starred: false,
          matchInfo: "Flawless blind baton handover in the third leg."
        },
        {
          id: "d3_05",
          dayId: "day3",
          title: "KURU26_D3_VOLLEYBALL_DIVE_DIG.JPG",
          sport: "Volleyball",
          venue: "Hard Court Arena",
          size: "5.2 MB",
          dimensions: "3840 x 2160",
          photographer: "Priya Nair",
          exif: "Sony A1 • 24-70mm • f/2.8 • 1/2000s • ISO 640",
          image: "assets/faq-player.png",
          starred: false,
          matchInfo: "Desperate pancake dig keeps the match point alive."
        },
        {
          id: "d3_06",
          dayId: "day3",
          title: "KURU26_D3_LONG_JUMP_SAND_EXPLOSION.JPG",
          sport: "Athletics",
          venue: "Sand Pit West",
          size: "6.7 MB",
          dimensions: "3840 x 2160",
          photographer: "Kabir Mehta",
          exif: "Sony A7 IV • 70-200mm • f/2.8 • 1/4000s • ISO 320",
          image: "assets/hero-player.png",
          starred: false,
          matchInfo: "7.42m leap landing into the sand with dynamic spray."
        },
        {
          id: "d3_07",
          dayId: "day3",
          title: "KURU26_D3_RELAY_TEARS_OF_JOY.JPG",
          sport: "Athletics",
          venue: "Podium Trackside",
          size: "4.9 MB",
          dimensions: "3840 x 2160",
          photographer: "Ananya Sen",
          exif: "Canon R6 • 85mm f/1.4 • f/1.8 • 1/1250s • ISO 200",
          image: "assets/collage-cheer.png",
          starred: false,
          matchInfo: "Embrace between the 4 sprinters clinching gold medal."
        },
        {
          id: "d3_08",
          dayId: "day3",
          title: "KURU26_D3_EVENING_TRACK_SILHOUETTES.JPG",
          sport: "Crowd & Vibes",
          venue: "Main Stadium Oval",
          size: "5.7 MB",
          dimensions: "3840 x 2160",
          photographer: "Aarav Sharma",
          exif: "Fujifilm GFX 100S • 45mm • f/2.8 • 1/500s • ISO 400",
          image: "assets/bento-court.png",
          starred: false,
          matchInfo: "Sunset silhouettes against the orange Pune hills."
        }
      ]
    },
    {
      id: "day4",
      name: "Day 04 - Grand Finals, Trophy & Gala",
      date: "Oct 21, 2026",
      shortTitle: "Day 04: Championship & Valedictory",
      itemCount: 8,
      size: "890 MB",
      folderDesc: "The grand finale: Championship trophy presentations, overall winner contingent crowned, fireworks, and EDM DJ Night celebration.",
      photos: [
        {
          id: "d4_01",
          dayId: "day4",
          title: "KURU26_D4_OVERALL_CHAMPIONS_LIFT_PHOENIX.JPG",
          sport: "Ceremonies",
          venue: "Main Stage Grand Amphitheater",
          size: "7.5 MB",
          dimensions: "4096 x 2304",
          photographer: "Aarav Sharma & Priya Nair",
          exif: "Sony A1 • 24-70mm f/2.8 GM • f/2.8 • 1/1600s • ISO 400",
          image: "assets/collage-cheer.png",
          starred: true,
          matchInfo: "FLAME University lifts the Overall Kurukshetra 2026 Championship Trophy!"
        },
        {
          id: "d4_02",
          dayId: "day4",
          title: "KURU26_D4_FOOTBALL_FINAL_PENALTY_WIN.JPG",
          sport: "Football",
          venue: "Main Turf Stadium",
          size: "6.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Rohan Varma",
          exif: "Sony A1 • 70-200mm GM • f/2.8 • 1/2500s • ISO 500",
          image: "assets/hero-player.png",
          starred: true,
          matchInfo: "Sudden death shootout save to secure the championship."
        },
        {
          id: "d4_03",
          dayId: "day4",
          title: "KURU26_D4_FIREWORKS_OVER_CAMPUS.JPG",
          sport: "Ceremonies",
          venue: "Sky over FLAME Plaza",
          size: "8.2 MB",
          dimensions: "3840 x 2160",
          photographer: "Kabir Mehta",
          exif: "Canon R5 • 24mm • f/8.0 • 2.5s • ISO 100",
          image: "assets/phoenix-web.png",
          starred: true,
          matchInfo: "Synchronized pyrotechnic show illuminating the Pune sky."
        },
        {
          id: "d4_04",
          dayId: "day4",
          title: "KURU26_D4_BASKETBALL_GOLD_MEDAL_MOMENT.JPG",
          sport: "Basketball",
          venue: "Indoor Hardwood Arena",
          size: "5.8 MB",
          dimensions: "3840 x 2160",
          photographer: "Vikram Malhotra",
          exif: "Nikon Z9 • 70-200mm • f/2.8 • 1/2000s • ISO 800",
          image: "assets/how-it-works-player.png",
          starred: true,
          matchInfo: "Final whistle tears and celebrations on the court."
        },
        {
          id: "d4_05",
          dayId: "day4",
          title: "KURU26_D4_DJ_NIGHT_CONCERT_CROWD.JPG",
          sport: "Crowd & Vibes",
          venue: "Festival Lawns",
          size: "7.0 MB",
          dimensions: "3840 x 2160",
          photographer: "Ananya Sen",
          exif: "Sony A7 IV • 16-35mm GM • f/2.8 • 1/500s • ISO 1600",
          image: "assets/collage-cheer.png",
          starred: false,
          matchInfo: "5,000+ students in unison during the headline DJ set."
        },
        {
          id: "d4_06",
          dayId: "day4",
          title: "KURU26_D4_EXECUTIVE_COMMITTEE_CURTAIN_CALL.JPG",
          sport: "Ceremonies",
          venue: "Main Amphitheater Stage",
          size: "6.4 MB",
          dimensions: "3840 x 2160",
          photographer: "Priya Nair",
          exif: "Sony A7 IV • 24-70mm • f/2.8 • 1/800s • ISO 320",
          image: "assets/hero-avatars.png",
          starred: false,
          matchInfo: "The 35 student committee heads bowed to thunderous applause."
        },
        {
          id: "d4_07",
          dayId: "day4",
          title: "KURU26_D4_TENNIS_RUNNER_UP_RESPECT.JPG",
          sport: "Tennis",
          venue: "Center Court",
          size: "5.3 MB",
          dimensions: "3840 x 2160",
          photographer: "Aarav Sharma",
          exif: "Canon R3 • 85mm • f/1.4 • 1/2000s • ISO 200",
          image: "assets/bento-player-serve.png",
          starred: false,
          matchInfo: "Sporting handshake and embrace after 3-hour marathon final."
        },
        {
          id: "d4_08",
          dayId: "day4",
          title: "KURU26_D4_PHOENIX_CREST_NIGHT_ILLUMINATION.JPG",
          sport: "Ceremonies",
          venue: "Plaza Central Monument",
          size: "6.9 MB",
          dimensions: "3840 x 2160",
          photographer: "Kabir Mehta",
          exif: "Sony A1 • 50mm f/1.2 • f/1.4 • 1/400s • ISO 800",
          image: "assets/phoenix-icon.png",
          starred: false,
          matchInfo: "The glowing phoenix emblem burning bright as Kurukshetra 2026 concludes."
        }
      ]
    }
  ]
};

// ==========================================================================
// 2. STATE MANAGEMENT
// ==========================================================================
let currentDayId = "day1";
let currentViewMode = "grid"; // 'grid' | 'list'
let currentFilterTag = "all";
let searchQuery = "";
let selectedFileIds = new Set();
let starredFileIds = new Set();
let activeLightboxIndex = 0;
let currentActiveDayPhotos = [];

// ==========================================================================
// 3. THREE.JS 3D HERO: KURUKSHETRA CRYSTAL PHOENIX SPINNING ON AXIS
// ==========================================================================
let scene, camera, renderer;
let carouselRig, phoenixCenterMesh, phoenixCrossMesh, shards = [], albumCards = [], emberParticles;
let targetRotX = 0.15, targetRotY = 0, currentRotX = 0.15, currentRotY = 0;
let autoSpinSpeed = 0.0035;
let isPointerDragging = false;
let pointerPrevX = 0, pointerPrevY = 0;
let raycaster, mouseNorm;
let hoveredCard = null;

// Automatic Page-Entrance Shatter Timeline
let entranceProgress = 0;
let entranceStartedAt = 0;

function initThreeHero() {
  const container = document.getElementById('threejs-hero-canvas');
  if (!container || typeof THREE === 'undefined') return;

  // Scene
  scene = new THREE.Scene();

  // Camera
  const width = container.clientWidth;
  const height = container.clientHeight;
  camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
  camera.position.set(0, 0.8, 11.2);

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.25;
  container.appendChild(renderer.domElement);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 1.1);
  scene.add(ambientLight);

  const flamePoint = new THREE.PointLight(0xfe5a00, 3.8, 25);
  flamePoint.position.set(0, 0.5, 3);
  scene.add(flamePoint);

  const amberPoint = new THREE.PointLight(0xfaad36, 2.5, 25);
  amberPoint.position.set(0, 2.5, -3);
  scene.add(amberPoint);

  // Central Rig (Rotates around vertical/inclined axis)
  carouselRig = new THREE.Group();
  carouselRig.rotation.x = 0.15;
  scene.add(carouselRig);

  // 1. Build the Kurukshetra Crystal Phoenix at the Center Axis
  buildKurukshetraCrystalPhoenix();

  // 2. Build the Radial Album Cards fanned out around the Phoenix
  build3DAlbumStarburst();

  // 3. Build Floating Crystal Shards
  buildFloatingCrystalShards();

  // 4. Build Fiery Swirling Particles
  buildEmberParticles();

  // Raycaster for Hover & Click
  raycaster = new THREE.Raycaster();
  mouseNorm = new THREE.Vector2(-999, -999);

  // Setup Mouse Interaction & Automatic Entrance Trigger
  setupThreeInteraction(container);

  // Record start time for entrance animation
  entranceStartedAt = performance.now();

  // Render Loop
  animateThree();
}

/**
 * 1. Centerpiece: The Official Kurukshetra Crystal Phoenix spinning on its axis
 */
function buildKurukshetraCrystalPhoenix() {
  const textureLoader = new THREE.TextureLoader();

  // Primary double-sided crystal plane
  const planeGeom = new THREE.PlaneGeometry(3.6, 5.0);

  // Load the user's provided official crystal phoenix
  textureLoader.load(
    'assets/phoenix-crystal.png',
    (tex) => {
      tex.generateMipmaps = true;
      tex.minFilter = THREE.LinearMipmapLinearFilter;

      const phoenixMat = new THREE.MeshStandardMaterial({
        map: tex,
        transparent: true,
        alphaTest: 0.05,
        side: THREE.DoubleSide,
        roughness: 0.2,
        metalness: 0.1,
        emissive: 0xfe5a00,
        emissiveIntensity: 0.25
      });

      phoenixCenterMesh = new THREE.Mesh(planeGeom, phoenixMat);
      phoenixCenterMesh.position.set(0, 0.2, 0);
      carouselRig.add(phoenixCenterMesh);

      // Secondary angled cross-plane for 3D crystalline depth when spinning on axis
      const crossMat = phoenixMat.clone();
      crossMat.opacity = 0.5;
      phoenixCrossMesh = new THREE.Mesh(planeGeom, crossMat);
      phoenixCrossMesh.position.set(0, 0.2, 0);
      phoenixCrossMesh.rotation.y = Math.PI / 2;
      carouselRig.add(phoenixCrossMesh);
    },
    undefined,
    () => {
      // Fallback procedural crystal diamond if image load fails
      const fallbackGeom = new THREE.OctahedronGeometry(1.6, 0);
      const fallbackMat = new THREE.MeshPhysicalMaterial({
        color: 0xfe5a00,
        emissive: 0xea5401,
        emissiveIntensity: 0.5,
        transmission: 0.7,
        roughness: 0.1
      });
      phoenixCenterMesh = new THREE.Mesh(fallbackGeom, fallbackMat);
      carouselRig.add(phoenixCenterMesh);
    }
  );
}

/**
 * Procedural fallback Canvas texture for 3D cards
 */
function createProceduralCardCanvas(photoData, index) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 740;
  const ctx = canvas.getContext('2d');

  // Background
  const grad = ctx.createLinearGradient(0, 0, 512, 740);
  grad.addColorStop(0, '#0c1018');
  grad.addColorStop(0.5, '#161c2b');
  grad.addColorStop(1, '#080a0f');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 740);

  // Border lines
  ctx.strokeStyle = 'rgba(254, 90, 0, 0.45)';
  ctx.lineWidth = 3;
  ctx.strokeRect(18, 18, 476, 704);

  // Header
  ctx.font = 'bold 24px "League Spartan", sans-serif';
  ctx.fillStyle = '#FE5A00';
  ctx.fillText('KURUKSHETRA 2026', 40, 70);

  ctx.font = '16px "Montserrat", sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(`${photoData.dayId.toUpperCase()} • ASSET #${String(index + 1).padStart(2, '0')}`, 40, 100);

  // Center Art Box
  const centerGrad = ctx.createRadialGradient(256, 320, 20, 256, 320, 180);
  centerGrad.addColorStop(0, 'rgba(254, 90, 0, 0.3)');
  centerGrad.addColorStop(1, 'rgba(0, 0, 0, 0.6)');
  ctx.fillStyle = centerGrad;
  ctx.fillRect(40, 130, 432, 380);

  // Sport Icon
  const icons = {
    Football: '⚽',
    Basketball: '🏀',
    Tennis: '🎾',
    Badminton: '🏸',
    Athletics: '🏃',
    Volleyball: '🏐',
    Ceremonies: '🔥',
    'Crowd & Vibes': '🏆'
  };
  const icon = icons[photoData.sport] || '🔥';
  ctx.font = '96px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(icon, 256, 320);

  // Sport Tag
  ctx.textAlign = 'left';
  ctx.fillStyle = '#FE5A00';
  ctx.font = '800 36px "League Spartan", sans-serif';
  ctx.fillText(photoData.sport.toUpperCase(), 40, 580);

  ctx.fillStyle = '#ffffff';
  ctx.font = '600 20px "DM Sans", sans-serif';
  ctx.fillText(photoData.title.length > 28 ? photoData.title.substring(0, 26) + '...' : photoData.title, 40, 615);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '15px "Space Grotesk", monospace';
  ctx.fillText(`${photoData.dimensions} • ${photoData.size}`, 40, 650);

  return new THREE.CanvasTexture(canvas);
}

/**
 * 2. Radial Starburst Album Cards fanned out around the Phoenix
 */
function build3DAlbumStarburst() {
  const cardCount = 14;
  const radius = 3.8;
  const cardW = 1.9;
  const cardH = 2.8;

  const allPhotos = [];
  ARCHIVE_DATA.days.forEach(d => allPhotos.push(...d.photos));

  const textureLoader = new THREE.TextureLoader();

  for (let i = 0; i < cardCount; i++) {
    const angle = (i / cardCount) * Math.PI * 2;
    const photoData = allPhotos[i % allPhotos.length];

    const cardGeom = new THREE.PlaneGeometry(cardW, cardH);

    // Initial procedural fallback texture
    const fallbackTexture = createProceduralCardCanvas(photoData, i);
    const frontMat = new THREE.MeshStandardMaterial({
      map: fallbackTexture,
      side: THREE.DoubleSide,
      roughness: 0.35,
      metalness: 0.15
    });

    // Attempt real image texture load
    textureLoader.load(
      photoData.image,
      (loadedTex) => {
        frontMat.map = loadedTex;
        frontMat.needsUpdate = true;
      },
      undefined,
      () => {}
    );

    const cardMesh = new THREE.Mesh(cardGeom, frontMat);

    // Final target position (fanned out starburst around axis)
    const targetX = Math.sin(angle) * radius;
    const targetZ = Math.cos(angle) * radius;
    const targetY = Math.sin(angle * 2) * 0.3;

    // Start near center for automatic page-entrance burst
    cardMesh.position.set(targetX * 0.15, targetY * 0.15, targetZ * 0.15);

    cardMesh.rotation.y = angle + Math.PI / 2;
    cardMesh.rotation.x = 0.22;
    cardMesh.rotation.z = Math.sin(angle) * 0.12;

    cardMesh.userData = {
      index: i,
      photo: photoData,
      targetPos: new THREE.Vector3(targetX, targetY, targetZ),
      initialPos: new THREE.Vector3(targetX * 0.15, targetY * 0.15, targetZ * 0.15),
      initialRot: new THREE.Euler(cardMesh.rotation.x, cardMesh.rotation.y, cardMesh.rotation.z),
      angle: angle,
      isCard: true
    };

    // Border glow line
    const borderEdges = new THREE.EdgesGeometry(cardGeom);
    const borderMat = new THREE.LineBasicMaterial({
      color: 0xfe5a00,
      linewidth: 2,
      transparent: true,
      opacity: 0.65
    });
    const borderLine = new THREE.LineSegments(borderEdges, borderMat);
    cardMesh.add(borderLine);

    carouselRig.add(cardMesh);
    albumCards.push(cardMesh);
  }
}

/**
 * 3. Floating Crystalline Shards (Procedural crystal facets)
 */
function buildFloatingCrystalShards() {
  const crystalMat = new THREE.MeshPhysicalMaterial({
    color: 0xfe5a00,
    emissive: 0xea5401,
    emissiveIntensity: 0.3,
    roughness: 0.15,
    metalness: 0.1,
    transmission: 0.6,
    thickness: 1.0,
    reflectivity: 0.9,
    clearcoat: 1.0
  });

  const goldCrystalMat = new THREE.MeshPhysicalMaterial({
    color: 0xfaad36,
    emissive: 0xfe5a00,
    emissiveIntensity: 0.35,
    roughness: 0.2,
    metalness: 0.2,
    transmission: 0.5,
    thickness: 0.8
  });

  const shardCount = 20;
  for (let s = 0; s < shardCount; s++) {
    const shardGeom = new THREE.ConeGeometry(0.18 + (s % 3) * 0.05, 0.9 + (s % 4) * 0.2, 3);
    const mesh = new THREE.Mesh(shardGeom, s % 2 === 0 ? crystalMat : goldCrystalMat);

    const angle = (s / shardCount) * Math.PI * 2;
    const r = 1.4 + (s % 4) * 0.45;
    const targetX = Math.cos(angle) * r;
    const targetY = (s - shardCount / 2) * 0.22;
    const targetZ = Math.sin(angle) * r;

    mesh.position.set(targetX * 0.2, targetY * 0.2, targetZ * 0.2);
    mesh.rotation.x = Math.random() * Math.PI;
    mesh.rotation.y = Math.random() * Math.PI;
    mesh.rotation.z = Math.random() * Math.PI;

    mesh.userData = {
      targetPos: new THREE.Vector3(targetX, targetY, targetZ),
      initialPos: new THREE.Vector3(targetX * 0.2, targetY * 0.2, targetZ * 0.2),
      rotSpeed: new THREE.Vector3(Math.random() * 0.02, Math.random() * 0.02, Math.random() * 0.02)
    };

    carouselRig.add(mesh);
    shards.push(mesh);
  }
}

/**
 * 4. Fiery Swirling Particles (Embers)
 */
function buildEmberParticles() {
  const particleCount = 420;
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(particleCount * 3);
  const colors = new Float32Array(particleCount * 3);

  const colorFlame = new THREE.Color(0xfe5a00);
  const colorGold = new THREE.Color(0xfaad36);

  for (let i = 0; i < particleCount; i++) {
    const radius = 1.0 + Math.random() * 4.8;
    const angle = Math.random() * Math.PI * 2;
    const y = (Math.random() - 0.5) * 5.5;

    positions[i * 3] = Math.cos(angle) * radius;
    positions[i * 3 + 1] = y;
    positions[i * 3 + 2] = Math.sin(angle) * radius;

    const mixedColor = colorFlame.clone().lerp(colorGold, Math.random());
    colors[i * 3] = mixedColor.r;
    colors[i * 3 + 1] = mixedColor.g;
    colors[i * 3 + 2] = mixedColor.b;
  }

  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const material = new THREE.PointsMaterial({
    size: 0.065,
    vertexColors: true,
    transparent: true,
    opacity: 0.75,
    blending: THREE.AdditiveBlending
  });

  emberParticles = new THREE.Points(geometry, material);
  carouselRig.add(emberParticles);
}

/**
 * Setup Mouse, Drag & Pointer Interaction
 */
function setupThreeInteraction(container) {
  // Move around axis with mouse pointer
  window.addEventListener('mousemove', (e) => {
    const rect = container.getBoundingClientRect();
    if (e.clientY <= rect.bottom && e.clientY >= rect.top) {
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -(((e.clientY - rect.top) / rect.height) * 2 - 1);

      mouseNorm.x = nx;
      mouseNorm.y = ny;

      if (!isPointerDragging) {
        targetRotY += nx * 0.0018;
        targetRotX = 0.15 + (ny * 0.22);
      }
    }
  });

  // Drag to spin wheel with momentum
  container.addEventListener('mousedown', (e) => {
    isPointerDragging = true;
    pointerPrevX = e.clientX;
    pointerPrevY = e.clientY;
  });

  window.addEventListener('mouseup', () => {
    isPointerDragging = false;
  });

  window.addEventListener('mousemove', (e) => {
    if (isPointerDragging) {
      const deltaX = e.clientX - pointerPrevX;
      const deltaY = e.clientY - pointerPrevY;

      targetRotY += deltaX * 0.008;
      targetRotX += deltaY * 0.005;
      targetRotX = Math.max(-0.5, Math.min(0.7, targetRotX));

      pointerPrevX = e.clientX;
      pointerPrevY = e.clientY;
    }
  });

  // Touch Drag for Mobile
  container.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
      isPointerDragging = true;
      pointerPrevX = e.touches[0].clientX;
      pointerPrevY = e.touches[0].clientY;
    }
  }, { passive: true });

  window.addEventListener('touchend', () => {
    isPointerDragging = false;
  });

  window.addEventListener('touchmove', (e) => {
    if (isPointerDragging && e.touches.length === 1) {
      const deltaX = e.touches[0].clientX - pointerPrevX;
      const deltaY = e.touches[0].clientY - pointerPrevY;

      targetRotY += deltaX * 0.01;
      targetRotX += deltaY * 0.007;

      pointerPrevX = e.touches[0].clientX;
      pointerPrevY = e.touches[0].clientY;
    }
  }, { passive: true });

  // Click on 3D card -> Scroll to Google Drive & Open Lightbox
  container.addEventListener('click', () => {
    if (hoveredCard && hoveredCard.userData && hoveredCard.userData.photo) {
      const photo = hoveredCard.userData.photo;
      switchDayFolder(photo.dayId);
      scrollToDrive();
      setTimeout(() => {
        openLightboxByPhoto(photo);
      }, 450);
    }
  });

  // Window Resize
  window.addEventListener('resize', () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });
}

/**
 * 3D Animation Render Loop
 */
function animateThree() {
  requestAnimationFrame(animateThree);

  // Automatic Page-Entrance Timeline (Smoothly expands Phoenix cards on arrival)
  const elapsed = (performance.now() - entranceStartedAt) / 1000;
  if (elapsed < 3.0) {
    entranceProgress = Math.min(1.0, elapsed / 2.2);
    // Smooth easeOutCubic
    const t = 1 - Math.pow(1 - entranceProgress, 3);

    // Expand album cards outward from center
    albumCards.forEach(card => {
      card.position.lerpVectors(card.userData.initialPos, card.userData.targetPos, t);
    });

    // Expand crystal shards outward
    shards.forEach(shard => {
      shard.position.lerpVectors(shard.userData.initialPos, shard.userData.targetPos, t);
    });
  }

  // Smooth lerp for rotation
  currentRotX += (targetRotX - currentRotX) * 0.06;
  currentRotY += (targetRotY - currentRotY) * 0.06;

  // Continuous rotation on vertical axis
  targetRotY += autoSpinSpeed;

  carouselRig.rotation.y = currentRotY;
  carouselRig.rotation.x = currentRotX;

  // Gently pulse and tumble floating crystal shards
  shards.forEach(shard => {
    if (shard.userData.rotSpeed) {
      shard.rotation.x += shard.userData.rotSpeed.x;
      shard.rotation.y += shard.userData.rotSpeed.y;
    }
  });

  // Swirl ember particles
  if (emberParticles) {
    emberParticles.rotation.y += 0.002;
  }

  // Raycasting for hovered card
  if (camera && albumCards.length > 0) {
    raycaster.setFromCamera(mouseNorm, camera);
    const intersects = raycaster.intersectObjects(albumCards);

    const tooltip = document.getElementById('hero-card-tooltip');
    const tooltipText = document.getElementById('tooltip-photo-title');

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      if (hoveredCard !== hit) {
        if (hoveredCard) hoveredCard.scale.set(1, 1, 1);
        hoveredCard = hit;
        hoveredCard.scale.set(1.1, 1.1, 1.1);

        if (tooltip && tooltipText && hit.userData.photo) {
          tooltipText.textContent = `${hit.userData.photo.sport.toUpperCase()} • ${hit.userData.photo.title}`;
          tooltip.classList.add('visible');
        }
      }
    } else {
      if (hoveredCard) {
        hoveredCard.scale.set(1, 1, 1);
        hoveredCard = null;
      }
      if (tooltip) tooltip.classList.remove('visible');
    }
  }

  renderer.render(scene, camera);
}

// ==========================================================================
// 4. GOOGLE DRIVE MIMIC ARCHIVE ENGINE (LAYOUT ONLY - NO ADD/REMOVE)
// ==========================================================================

function initDriveArchive() {
  renderDayFolders();
  renderCurrentFolderView();
  setupDriveEventListeners();
}

/**
 * Render the 4 Day Folders at the top of the Drive section
 */
function renderDayFolders() {
  const container = document.getElementById('drive-folders-grid');
  if (!container) return;

  container.innerHTML = '';

  ARCHIVE_DATA.days.forEach(day => {
    const isActive = day.id === currentDayId;
    const card = document.createElement('div');
    card.className = `drive-folder-card ${isActive ? 'active' : ''}`;
    card.dataset.dayId = day.id;

    card.innerHTML = `
      <div class="folder-icon-wrapper">
        <span style="color:#FE5A00;">📁</span>
      </div>
      <div class="folder-meta">
        <h4 class="folder-name">${day.name}</h4>
        <p class="folder-stats">${day.date} • ${day.itemCount} Items • ${day.size}</p>
      </div>
      <button class="folder-download-btn" title="Download ${day.shortTitle} (.ZIP)" data-day-id="${day.id}">
        ⬇
      </button>
    `;

    // Click folder to open
    card.addEventListener('click', (e) => {
      if (e.target.closest('.folder-download-btn')) {
        e.stopPropagation();
        triggerFolderZipDownload(day.id);
        return;
      }
      switchDayFolder(day.id);
    });

    container.appendChild(card);
  });
}

/**
 * Switch active Day Folder & update breadcrumbs
 */
function switchDayFolder(dayId) {
  currentDayId = dayId;

  // Update folder cards active styling
  document.querySelectorAll('.drive-folder-card').forEach(c => {
    c.classList.toggle('active', c.dataset.dayId === dayId);
  });

  // Update sidebar active folder
  document.querySelectorAll('.sidebar-nav-item[data-day-id]').forEach(item => {
    item.classList.toggle('active', item.dataset.dayId === dayId);
  });

  // Re-render contents
  renderCurrentFolderView();
}

/**
 * Render current folder contents (Grid view or List view)
 */
function renderCurrentFolderView() {
  const day = ARCHIVE_DATA.days.find(d => d.id === currentDayId) || ARCHIVE_DATA.days[0];
  if (!day) return;

  // Update Breadcrumbs
  const breadcrumbEl = document.getElementById('breadcrumb-current-folder');
  if (breadcrumbEl) breadcrumbEl.textContent = day.name;

  // Update Folder Header
  const titleEl = document.getElementById('active-folder-title');
  const countEl = document.getElementById('active-folder-count');
  const descEl = document.getElementById('active-folder-desc');

  if (titleEl) titleEl.textContent = day.name;
  if (countEl) countEl.textContent = `${day.itemCount} Assets • ${day.size}`;
  if (descEl) descEl.textContent = day.folderDesc;

  // Filter photos
  let photos = [...day.photos];

  // Apply Tag Filter
  if (currentFilterTag !== 'all') {
    if (currentFilterTag === 'starred') {
      photos = photos.filter(p => p.starred || starredFileIds.has(p.id));
    } else {
      photos = photos.filter(p => p.sport.toLowerCase().includes(currentFilterTag.toLowerCase()));
    }
  }

  // Apply Search Query
  if (searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    photos = photos.filter(p => 
      p.title.toLowerCase().includes(q) ||
      p.sport.toLowerCase().includes(q) ||
      p.venue.toLowerCase().includes(q) ||
      p.photographer.toLowerCase().includes(q) ||
      p.matchInfo.toLowerCase().includes(q)
    );
  }

  currentActiveDayPhotos = photos;

  // Render Grid
  renderPhotosGrid(photos);

  // Render List
  renderPhotosList(photos);

  updateBulkSelectionState();
}

/**
 * Render Photos Grid
 */
function renderPhotosGrid(photos) {
  const gridContainer = document.getElementById('files-grid-view');
  if (!gridContainer) return;

  gridContainer.innerHTML = '';

  if (photos.length === 0) {
    gridContainer.innerHTML = `
      <div style="grid-column: 1 / -1; text-align:center; padding: 60px 20px; color: rgba(255,255,255,0.5);">
        <p style="font-size: 2rem; margin-bottom: 12px;">🔍</p>
        <p>No photos found matching your search in this day folder.</p>
        <button id="btn-reset-search" style="margin-top: 14px; background: rgba(254,90,0,0.15); border: 1px solid var(--color-primary-flame); color: var(--color-primary-flame); padding: 8px 18px; border-radius: 9999px; cursor: pointer; font-size: 0.85rem; font-weight:600;">
          Clear Filters
        </button>
      </div>
    `;
    const resetBtn = document.getElementById('btn-reset-search');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        searchQuery = '';
        currentFilterTag = 'all';
        const searchInput = document.getElementById('drive-search-input');
        if (searchInput) searchInput.value = '';
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        document.querySelector('.filter-chip[data-filter="all"]')?.classList.add('active');
        renderCurrentFolderView();
      });
    }
    return;
  }

  photos.forEach((photo) => {
    const isSelected = selectedFileIds.has(photo.id);
    const isStarred = photo.starred || starredFileIds.has(photo.id);

    const card = document.createElement('div');
    card.className = `drive-file-card ${isSelected ? 'selected' : ''}`;
    card.dataset.photoId = photo.id;

    card.innerHTML = `
      <div class="file-thumb-box" data-photo-id="${photo.id}">
        <img src="${photo.image}" alt="${photo.title}" class="file-thumb-img" loading="lazy">
        
        <div class="thumb-overlay">
          <div class="thumb-overlay-top">
            <input type="checkbox" class="file-select-checkbox" data-photo-id="${photo.id}" ${isSelected ? 'checked' : ''}>
            <button class="btn-star-item ${isStarred ? 'starred' : ''}" data-photo-id="${photo.id}" title="Star photo">
              ★
            </button>
          </div>

          <div class="thumb-overlay-bottom">
            <button class="btn-quick-preview" data-photo-id="${photo.id}">
              👁 Preview
            </button>
            <button class="btn-card-direct-download" data-photo-id="${photo.id}" title="Download high-res image">
              ⬇
            </button>
          </div>
        </div>
      </div>

      <div class="file-card-body">
        <div class="file-title-row">
          <span class="file-type-icon">🖼</span>
          <span class="file-title" title="${photo.title}">${photo.title}</span>
        </div>
        <div class="file-meta-row">
          <span class="file-sport-tag">${photo.sport}</span>
          <span>${photo.size}</span>
        </div>
      </div>
    `;

    // Click handlers
    const thumbBox = card.querySelector('.file-thumb-box');
    thumbBox.addEventListener('click', (e) => {
      if (e.target.closest('.file-select-checkbox') || e.target.closest('.btn-star-item') || e.target.closest('.btn-card-direct-download')) {
        return;
      }
      openLightboxByPhoto(photo);
    });

    // Checkbox toggle
    const checkbox = card.querySelector('.file-select-checkbox');
    checkbox.addEventListener('change', (e) => {
      togglePhotoSelection(photo.id, e.target.checked);
    });

    // Star toggle
    const starBtn = card.querySelector('.btn-star-item');
    starBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      togglePhotoStar(photo.id);
    });

    // Direct Download
    const dlBtn = card.querySelector('.btn-card-direct-download');
    dlBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      downloadSinglePhoto(photo);
    });

    gridContainer.appendChild(card);
  });
}

/**
 * Render Photos List Table
 */
function renderPhotosList(photos) {
  const tableBody = document.getElementById('drive-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '';

  photos.forEach(photo => {
    const isSelected = selectedFileIds.has(photo.id);
    const isStarred = photo.starred || starredFileIds.has(photo.id);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <input type="checkbox" class="file-select-checkbox" data-photo-id="${photo.id}" ${isSelected ? 'checked' : ''}>
      </td>
      <td>
        <div class="list-file-name-cell" style="cursor:pointer;">
          <img src="${photo.image}" class="list-file-thumb" alt="${photo.title}">
          <span>${photo.title}</span>
        </div>
      </td>
      <td><span class="file-sport-tag">${photo.sport}</span></td>
      <td>${photo.photographer}</td>
      <td>${photo.size}</td>
      <td>
        <div class="list-actions-cell">
          <button class="btn-list-action btn-star-item ${isStarred ? 'starred' : ''}" data-photo-id="${photo.id}" title="Star">★</button>
          <button class="btn-list-action btn-list-preview" data-photo-id="${photo.id}" title="Preview">👁</button>
          <button class="btn-list-action btn-list-download" data-photo-id="${photo.id}" title="Download">⬇</button>
        </div>
      </td>
    `;

    tr.querySelector('.list-file-name-cell').addEventListener('click', () => openLightboxByPhoto(photo));
    tr.querySelector('.btn-list-preview').addEventListener('click', () => openLightboxByPhoto(photo));
    tr.querySelector('.btn-list-download').addEventListener('click', () => downloadSinglePhoto(photo));
    tr.querySelector('.btn-star-item').addEventListener('click', () => togglePhotoStar(photo.id));

    tr.querySelector('.file-select-checkbox').addEventListener('change', (e) => {
      togglePhotoSelection(photo.id, e.target.checked);
    });

    tableBody.appendChild(tr);
  });
}

/**
 * Star / Favorite Toggle
 */
function togglePhotoStar(photoId) {
  if (starredFileIds.has(photoId)) {
    starredFileIds.delete(photoId);
  } else {
    starredFileIds.add(photoId);
  }

  document.querySelectorAll(`.btn-star-item[data-photo-id="${photoId}"]`).forEach(btn => {
    btn.classList.toggle('starred', starredFileIds.has(photoId));
  });
}

/**
 * Multi-Select Toggle
 */
function togglePhotoSelection(photoId, isChecked) {
  if (isChecked) {
    selectedFileIds.add(photoId);
  } else {
    selectedFileIds.delete(photoId);
  }

  const card = document.querySelector(`.drive-file-card[data-photo-id="${photoId}"]`);
  if (card) card.classList.toggle('selected', isChecked);

  updateBulkSelectionState();
}

/**
 * Update Bulk Action Buttons (e.g. "Download 3 Selected")
 */
function updateBulkSelectionState() {
  const bulkBtn = document.getElementById('btn-bulk-download-selected');
  const countSpan = document.getElementById('selected-count-num');

  if (bulkBtn && countSpan) {
    const count = selectedFileIds.size;
    if (count > 0) {
      bulkBtn.classList.add('visible');
      countSpan.textContent = `(${count})`;
    } else {
      bulkBtn.classList.remove('visible');
    }
  }
}

/**
 * Real Browser Download for a Single Photo
 */
function downloadSinglePhoto(photo) {
  const link = document.createElement('a');
  link.href = photo.image;
  link.download = photo.title;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToastNotification(`⬇ Downloading ${photo.title} (${photo.size})`);
}

/**
 * Trigger ZIP packaging simulation and download for a day folder
 */
function triggerFolderZipDownload(dayId) {
  const day = ARCHIVE_DATA.days.find(d => d.id === dayId) || ARCHIVE_DATA.days[0];
  const modal = document.getElementById('zip-modal-overlay');
  const progressText = document.getElementById('zip-progress-text');
  const progressBar = document.getElementById('zip-progress-fill');

  if (modal) {
    modal.classList.add('open');
    if (progressText) progressText.textContent = `Packaging ${day.itemCount} high-res photos into ${day.shortTitle.replace(/[^a-zA-Z0-9]/g, '_')}.zip...`;
    if (progressBar) progressBar.style.width = '0%';

    let p = 0;
    const interval = setInterval(() => {
      p += 20;
      if (progressBar) progressBar.style.width = `${Math.min(p, 100)}%`;
      if (p >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          modal.classList.remove('open');
          showToastNotification(`✅ ${day.name} Archive Downloaded! (${day.size})`);

          // Trigger download of file
          const link = document.createElement('a');
          link.href = day.photos[0].image;
          link.download = `Kurukshetra2026_${day.id.toUpperCase()}_Album.zip`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }, 400);
      }
    }, 120);
  }
}

/**
 * Setup All Drive Toolbar, Search & Filter Listeners
 */
function setupDriveEventListeners() {
  // Search Input
  const searchInput = document.getElementById('drive-search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      if (searchClearBtn) {
        searchClearBtn.classList.toggle('visible', searchQuery.length > 0);
      }
      renderCurrentFolderView();
    });
  }

  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      searchClearBtn.classList.remove('visible');
      renderCurrentFolderView();
    });
  }

  // View Mode Toggle (Grid / List)
  const btnGrid = document.getElementById('view-toggle-grid');
  const btnList = document.getElementById('view-toggle-list');
  const gridView = document.getElementById('files-grid-view');
  const listView = document.getElementById('files-list-view');

  if (btnGrid && btnList && gridView && listView) {
    btnGrid.addEventListener('click', () => {
      currentViewMode = 'grid';
      btnGrid.classList.add('active');
      btnList.classList.remove('active');
      gridView.style.display = 'grid';
      listView.classList.remove('active');
    });

    btnList.addEventListener('click', () => {
      currentViewMode = 'list';
      btnList.classList.add('active');
      btnGrid.classList.remove('active');
      gridView.style.display = 'none';
      listView.classList.add('active');
    });
  }

  // Filter Chips
  document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentFilterTag = chip.dataset.filter || 'all';
      renderCurrentFolderView();
    });
  });

  // Sidebar Nav Items
  document.querySelectorAll('.sidebar-nav-item[data-day-id]').forEach(item => {
    item.addEventListener('click', () => {
      switchDayFolder(item.dataset.dayId);
    });
  });

  // Select All Button
  const btnSelectAll = document.getElementById('btn-select-all');
  if (btnSelectAll) {
    btnSelectAll.addEventListener('click', () => {
      const allSelected = currentActiveDayPhotos.every(p => selectedFileIds.has(p.id));
      if (allSelected) {
        currentActiveDayPhotos.forEach(p => selectedFileIds.delete(p.id));
        btnSelectAll.textContent = 'Select All';
      } else {
        currentActiveDayPhotos.forEach(p => selectedFileIds.add(p.id));
        btnSelectAll.textContent = 'Deselect All';
      }
      renderCurrentFolderView();
    });
  }

  // Bulk Download Selected
  const btnBulkDownload = document.getElementById('btn-bulk-download-selected');
  if (btnBulkDownload) {
    btnBulkDownload.addEventListener('click', () => {
      if (selectedFileIds.size === 0) return;
      showToastNotification(`📦 Packaging ${selectedFileIds.size} selected photos into ZIP...`);
      setTimeout(() => {
        const link = document.createElement('a');
        link.href = 'assets/collage-cheer.png';
        link.download = `Kurukshetra2026_Selected_${selectedFileIds.size}Photos.zip`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }, 800);
    });
  }

  // Download Current Folder ZIP Button in Header
  const btnFolderZip = document.getElementById('btn-download-folder-zip');
  if (btnFolderZip) {
    btnFolderZip.addEventListener('click', () => {
      triggerFolderZipDownload(currentDayId);
    });
  }

  // Breadcrumb Root Jump
  const breadcrumbRoot = document.getElementById('breadcrumb-root');
  if (breadcrumbRoot) {
    breadcrumbRoot.addEventListener('click', () => {
      switchDayFolder('day1');
    });
  }
}

// ==========================================================================
// 5. GOOGLE DRIVE LIGHTBOX MODAL
// ==========================================================================
function openLightboxByPhoto(photo) {
  const modal = document.getElementById('drive-lightbox-modal');
  if (!modal) return;

  activeLightboxIndex = currentActiveDayPhotos.findIndex(p => p.id === photo.id);
  if (activeLightboxIndex === -1) activeLightboxIndex = 0;

  updateLightboxContent();
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function updateLightboxContent() {
  const photo = currentActiveDayPhotos[activeLightboxIndex];
  if (!photo) return;

  const mainImg = document.getElementById('lightbox-main-img');
  const filename = document.getElementById('lightbox-filename');
  const sportTag = document.getElementById('lightbox-sport-tag');

  if (mainImg) mainImg.src = photo.image;
  if (filename) filename.textContent = photo.title;
  if (sportTag) sportTag.textContent = photo.sport;

  const infoDimensions = document.getElementById('info-dimensions');
  const infoSize = document.getElementById('info-size');
  const infoVenue = document.getElementById('info-venue');
  const infoPhotographer = document.getElementById('info-photographer');
  const infoExif = document.getElementById('info-exif');
  const infoMatch = document.getElementById('info-match');

  if (infoDimensions) infoDimensions.textContent = photo.dimensions;
  if (infoSize) infoSize.textContent = photo.size;
  if (infoVenue) infoVenue.textContent = photo.venue;
  if (infoPhotographer) infoPhotographer.textContent = photo.photographer;
  if (infoExif) infoExif.textContent = photo.exif;
  if (infoMatch) infoMatch.textContent = photo.matchInfo;
}

function closeLightbox() {
  const modal = document.getElementById('drive-lightbox-modal');
  if (modal) modal.classList.remove('open');
  document.body.style.overflow = '';
}

// Lightbox Navigation & Tools
document.addEventListener('DOMContentLoaded', () => {
  const btnClose = document.getElementById('lightbox-close-btn');
  const btnPrev = document.getElementById('lightbox-prev-btn');
  const btnNext = document.getElementById('lightbox-next-btn');
  const btnDownload = document.getElementById('lightbox-download-btn');
  const btnDrawerToggle = document.getElementById('lightbox-info-toggle');
  const drawer = document.getElementById('lightbox-info-drawer');

  if (btnClose) btnClose.addEventListener('click', closeLightbox);

  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      if (currentActiveDayPhotos.length === 0) return;
      activeLightboxIndex = (activeLightboxIndex - 1 + currentActiveDayPhotos.length) % currentActiveDayPhotos.length;
      updateLightboxContent();
    });
  }

  if (btnNext) {
    btnNext.addEventListener('click', () => {
      if (currentActiveDayPhotos.length === 0) return;
      activeLightboxIndex = (activeLightboxIndex + 1) % currentActiveDayPhotos.length;
      updateLightboxContent();
    });
  }

  if (btnDownload) {
    btnDownload.addEventListener('click', () => {
      const photo = currentActiveDayPhotos[activeLightboxIndex];
      if (photo) downloadSinglePhoto(photo);
    });
  }

  if (btnDrawerToggle && drawer) {
    btnDrawerToggle.addEventListener('click', () => {
      drawer.classList.toggle('collapsed');
    });
  }

  // Keyboard navigation
  window.addEventListener('keydown', (e) => {
    const modal = document.getElementById('drive-lightbox-modal');
    if (!modal || !modal.classList.contains('open')) return;

    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') btnPrev?.click();
    if (e.key === 'ArrowRight') btnNext?.click();
    if (e.key === 'd' || e.key === 'D') btnDownload?.click();
  });
});

// ==========================================================================
// 6. UTILITY FUNCTIONS
// ==========================================================================

function scrollToDrive() {
  const driveSection = document.getElementById('drive-archive-section');
  if (driveSection) {
    driveSection.scrollIntoView({ behavior: 'smooth' });
  }
}

function showToastNotification(message) {
  let toast = document.getElementById('global-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'global-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 28px;
      right: 28px;
      background: #141923;
      border: 1px solid var(--color-primary-flame);
      color: #fff;
      font-family: var(--font-body-dm-sans);
      font-size: 0.88rem;
      padding: 12px 20px;
      border-radius: 10px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.7), 0 0 15px rgba(254,90,0,0.3);
      z-index: 9999;
      display: flex;
      align-items: center;
      gap: 10px;
      transition: opacity 0.3s ease, transform 0.3s ease;
      opacity: 0;
      transform: translateY(15px);
    `;
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.style.opacity = '1';
  toast.style.transform = 'translateY(0)';

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(15px)';
  }, 3200);
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
  initThreeHero();
  initDriveArchive();
});
