/**
 * FLAME KURUKSHETRA 2026 - OFFICIAL BLOG & NEWSROOM SCRIPT
 * Full CRUD capabilities for EC / CC members, Read access for all visitors
 * Persistent LocalStorage • Dynamic Search & Filtering • Modal Reader
 */

(function () {
  'use strict';

  // Storage Keys
  const STORAGE_KEY_POSTS = 'kuru_blog_posts_v2';
  const STORAGE_KEY_AUTH = 'kuru_blog_auth_v2';
  const STORAGE_KEY_THEME = 'kuru_blog_theme';

  // Default Committee Passcodes
  const VALID_PASSCODES = ['kuru2026', 'ec2026', 'cc2026', 'flame2026', 'admin'];

  // Default Curated Stories (Including exact cards from user's reference mockup)
  const DEFAULT_STORIES = [
    {
      id: 'story-1',
      title: '10 AI tools that are transforming the way we work in 2026',
      category: 'Tools',
      tagColor: '#22c55e', // Green square from reference
      date: 'Apr 20, 2026',
      readTime: '5 min read',
      author: 'Ritisha Singh',
      role: 'CC Tech & Media Head',
      avatar: 'assets/heads/cc-tech.jpg',
      image: 'assets/blog-ref-1.png',
      excerpt: 'Discover the cutting-edge artificial intelligence suites streamlining sports analytics, match officiating, automated video highlight clipping, and collegiate event planning in 2026.',
      content: `## The Modern Intelligence Revolution in Collegiate Athletics

As technology advances into 2026, artificial intelligence has ceased to be an experimental tool and has become the backbone of modern campus festival logistics, competitive match preparation, and athletic performance tracking.

From high-precision ball tracking systems on the synthetic tennis courts to dynamic bracket balancing algorithms, tournament directors and athletes alike are experiencing a paradigm shift.

> "AI is no longer just for enterprise software. At Kurukshetra 2026, real-time computer vision assists our officiating teams, tracks player mileage on the football turf, and serves predictive scheduling notifications to 2,000+ collegiate athletes." — Ritisha Singh, CC Tech Head

### Top 5 Ways AI is Revolutionizing Sports Festivals in 2026:
- **Autonomous Video Curation:** Neural networks automatically detect key plays, goals, and game-winning aces to generate instant social highlight reels.
- **Biometric Heatmaps & Load Monitoring:** Non-invasive camera feeds compute athlete fatigue, allowing team coaches to prevent hamstring strains during intense multi-match weekends.
- **Dynamic Queue & Crowd Flow Optimization:** Real-time sensor vision balances spectator flow between the indoor sports complex and the outdoor football stadium.
- **Smart Rulebook Interpretation:** Instant conversational retrieval for intricate rule queries across 20 distinct disciplines.
- **Decentralized Fixture Integrity:** Algorithms simulate knockout seedings to prevent unfair match scheduling bottlenecks.

Whether you are competing in the cricket knockout or spectating at Kalakaar Katta, AI ensures every moment of the festival operates like a finely tuned engine.`
    },
    {
      id: 'story-2',
      title: 'Understanding the basics of modern machine learning',
      category: 'Guides',
      tagColor: '#3b82f6', // Blue square from reference
      date: 'Mar 17, 2026',
      readTime: '7 min read',
      author: 'Kabir Mehta',
      role: 'CC Sports & Analytics Head',
      avatar: 'assets/heads/cc-sports.jpg',
      image: 'assets/blog-ref-2.png',
      excerpt: 'A practical guide to the core principles of predictive neural networks and data science modeling applied to athletic performance, player load monitoring, and live tournament ranking algorithms.',
      content: `## Demystifying Machine Learning for Sports & Festival Strategy

Machine Learning (ML) can feel intimidating when buried under complex equations, but its fundamental intuition is remarkably simple: learning patterns from historical data to make accurate predictions about future outcomes.

In this guide, we break down how ML works and how the Kurukshetra tech team applies these models to power live tournament power-rankings.

### 1. Supervised Learning: The Foundation of Outcome Prediction
In supervised learning, models are fed labeled historical datasets—such as the last 5 seasons of FLAME vs IIT Bombay football fixtures, tracking possession percentages, shot accuracy, and defensive recovery speeds.

\`\`\`
Historical Features (Possession, Shot Conversion) ➔ Machine Learning Model ➔ Predicted Victory Probability
\`\`\`

### 2. Reinforcement Learning: Real-Time Court Scheduling
With unpredictable rain delays and overtime matches, static scheduling software fails. Kurukshetra employs reinforcement agents that optimize court assignments dynamically, penalizing schedule overruns and minimizing idle court downtime.

### Key Takeaways for Students:
- Machine learning is pattern recognition scaled to immense datasets.
- Clean data inputs matter far more than model complexity.
- Transparent heuristics combined with neural estimators create the fairest tournament brackets.`
    },
    {
      id: 'story-3',
      title: 'The role of AI in shaping today’s modern technology landscape',
      category: 'Insights',
      tagColor: '#f43f5e', // Pink/Coral square from reference
      date: 'Mar 3, 2026',
      readTime: '6 min read',
      author: 'Ananya Iyer',
      role: 'EC President',
      avatar: 'assets/heads/ec-president.jpg',
      image: 'assets/blog-ref-3.png',
      excerpt: 'An in-depth op-ed discussing how emerging intelligent compute architectures are redefining collegiate festivals, spectator interaction, decentralized scoring verification, and hybrid event broadcast.',
      content: `## A Technological Epoch: The New Architecture of Human Potential

We stand at a critical juncture where human athletic grit and computational intelligence converge. When 2,000 athletes from 60+ universities arrive at FLAME University for Kurukshetra 2026, they are not only participating in sports—they are experiencing the frontier of connected campus technology.

### Beyond Automation: The Era of Intelligent Immersion
Traditional sports festivals operated on whistle-blows, paper clipboards, and delayed printed brackets. Today, every point scored on our basketball hardwood is digitized within 200 milliseconds.

> "The true measure of technology is not its complexity, but how seamlessly it amplifies the human spirit. The Phoenix represents timeless endurance; modern technology simply gives wings to our ambition."

### Three Pillars Defining Our Digital Infrastructure:
1. **Zero-Latency Spectator Feeds:** Real-time synchronized live-streams with interactive multi-angle camera switching.
2. **Accessible Micro-Credentials:** Contingent captains manage roster certifications, eligibility waivers, and protest submissions through a unified cryptographic portal.
3. **Eco-Conscious Resource Routing:** Intelligent power routing reduces campus illumination waste during non-game hours by 34%.

As Kurukshetra continues to evolve, our commitment remains unshakeable: to celebrate collegiate athletic brilliance with world-class organization.`
    },
    {
      id: 'story-4',
      title: 'Rising From The Ashes: The Evolution of Kurukshetra\'s Phoenix',
      category: 'Heritage',
      tagColor: '#FE5A00', // Flame orange
      date: 'Oct 21, 2026',
      readTime: '5 min read',
      author: 'Ananya Iyer',
      role: 'EC President',
      avatar: 'assets/heads/ec-president.jpg',
      image: 'assets/hero-player.png',
      excerpt: 'How a collegiate sports meet grew into Western India\'s premier sporting festival, adopting the legendary firebird as its symbol of unyielding tenacity.',
      content: `## The Phoenix: Born of Grit and Unyielding Spirit

Every collegiate festival has a mascot, but very few embody a living, breathing philosophy like the Kurukshetra Phoenix.

When Kurukshetra began over a decade ago on the lush campus grounds of FLAME University in Pune, it was a spirited gathering of regional colleges. Yet, there was something distinctive about the energy: games played under the cool mountain winds of Lavale, fierce competition fought with unyielding sportsmanship, and nights illuminated by shared cultural celebration.

### The Myth and the Reality
In Greek and Vedic mythology, the Phoenix is immortal because it never admits defeat. When reduced to ashes, it reconstitutes itself with renewed vigor. In athletic terms, this is the definition of grit:

- The basketball squad trailing by 14 points with three minutes left on the clock.
- The marathoner running through cramps in the final uphill stretch of the Lavale valley.
- The doubles badminton pair saving 4 consecutive match points in a decider third set.

The Phoenix is not about never failing; it is about rising every single time you fall. Wear the flame proudly.`
    },
    {
      id: 'story-5',
      title: 'Inside The Rivalries: The FLAME vs IIT Bombay Football Clashes',
      category: 'Sports',
      tagColor: '#10b981', // Emerald green
      date: 'Oct 20, 2026',
      readTime: '4 min read',
      author: 'Kabir Mehta',
      role: 'CC Sports & Fixtures Head',
      avatar: 'assets/heads/cc-sports.jpg',
      image: 'assets/collage-run.png',
      excerpt: 'Over time, no matchup has brought more electric crowd energy to the Pune night turf than the annual gridiron derby between the Lions and the Bombay contingent.',
      content: `## 90 Minutes of Pure Adrenaline Under the Floodlights

Ask any veteran Kurukshetra spectator which match they circle on their calendar first, and the answer is unanimous: the FLAME vs IIT Bombay men's football showdown.

The rivalry dates back to 2018, when an unranked FLAME eleven stunned the reigning Mumbai champions in a dramatic penalty shootout. Ever since, every iteration of this match has played out like a championship thriller.

### Tactical Keys to the 2026 Clash:
- **Midfield Dominance:** FLAME's tactical 4-3-3 relies heavily on high pressing and rapid wing transitions, while IIT Bombay favors structured low-block counter-attacking.
- **The 12th Man Factor:** With over 1,500 students packing the sideline stands chanting rhythmically, communication on the pitch becomes a test of sheer composure.
- **Goalkeeping Brilliance:** Both keepers recorded save percentages above 88% in the qualifiers.

Kickoff is slated for Saturday night, 8:00 PM at the Main Turf Stadium. Arrive early to secure your seat.`
    },
    {
      id: 'story-6',
      title: 'Behind Kalakaar Katta: The Making of FLAME\'s Most Intimate Stage',
      category: 'Cultural',
      tagColor: '#8b5cf6', // Purple
      date: 'Oct 19, 2026',
      readTime: '6 min read',
      author: 'Dia Sen',
      role: 'CC Cultural Affairs Head',
      avatar: 'assets/heads/cc-cultural.jpg',
      image: 'assets/collage-cheer.png',
      excerpt: 'A look into the late-night acoustic jams, indie music discoveries, and poetry circles that give Kurukshetra its artistic heartbeat.',
      content: `## Where Acoustic Soul Meets Raw Street Energy

While the athletic stadiums roar with competition during the daytime, as dusk settles over the Western Ghats, a different magic awakens at Kalakaar Katta.

Conceived as an unplugged artistic sanctuary, Kalakaar Katta brings together student musicians, beatboxers, slam poets, and visual artists under fairy lights and bamboo pavilions.

### What to Expect at Katta 2026:
1. **Unplugged Sunset Sessions:** Acoustic indie singer-songwriters performing original compositions.
2. **The 1-on-1 Hip-Hop Cypher:** Pune's finest collegiate street dancers battling in popping, locking, and breaking.
3. **Live Canvas Murals:** Watch artists create a collaborative 20-foot Phoenix mural across the four festival days.

No scores, no knockouts, just pure, unfiltered artistic expression.`
    },
    {
      id: 'story-7',
      title: 'The Grand Schedule Unveiled: 4 Days, 20 Disciplines, 1 Champion',
      category: 'Guides',
      tagColor: '#3b82f6', // Blue
      date: 'Oct 18, 2026',
      readTime: '4 min read',
      author: 'Zayn Merchant',
      role: 'EC Operations & Fixtures',
      avatar: 'assets/heads/ec-operations.jpg',
      image: 'assets/cta-court.png',
      excerpt: 'Complete breakdown of sports fixtures, cultural showcases, and ME flagship arenas spanning October 24 to 27 across the FLAME campus.',
      content: `## Your Comprehensive 4-Day Championship Compass

With over 120 individual fixtures and simultaneous matches spanning three distinct campus zones, navigation is key. Here is your essential schedule blueprint:

- **Day 1 (Friday, Oct 24):** Opening Ceremony, Group Stage Football, Badminton Prelims, and Shark Arena Round 1.
- **Day 2 (Saturday, Oct 25):** Cricket T20 Quarters, Lawn Tennis Knockouts, Battle of the Bands, and Kalakaar Katta Launch.
- **Day 3 (Sunday, Oct 26):** Basketball Semifinals, Track & Field Finals, Esports Grand Finals, and Fashion Promenade.
- **Day 4 (Monday, Oct 27):** Championship Sunday — The Football & Basketball Finals, followed by the Grand Award Ceremony & DJ Night.

Check out the interactive Master Schedule page on the navigation bar for court-by-court live status updates.`
    },
    {
      id: 'story-8',
      title: 'Racket Sports Masterclass: Tactical Breakdown of Lawn Tennis & Padel',
      category: 'Sports',
      tagColor: '#10b981', // Emerald
      date: 'Oct 16, 2026',
      readTime: '5 min read',
      author: 'Kabir Mehta',
      role: 'CC Sports Head',
      avatar: 'assets/heads/cc-sports.jpg',
      image: 'assets/card-racket.png',
      excerpt: 'Our expert analysts dissect the court speed, spin physics, and collegiate doubles dynamics ahead of the Kurukshetra Open.',
      content: `## High Bounce and Fast Rallies: Navigating the Lavale Hardcourts

The tennis courts at FLAME University sit at an altitude of approximately 600 meters above sea level. This unique elevation means the air is slightly thinner, resulting in faster ball travel and higher kick on heavy topspin serves.

### Padel: The Debut Sensation
For the first time in Kurukshetra history, Padel tennis has been introduced as an official competitive discipline. Combining the agility of squash with the tactical volleys of doubles tennis, the glass-enclosed court promises rapid-fire rallies.

Watch out for the defending doubles champions from St. Xavier's Mumbai, who enter as top seeds in both men's and women's draws.`
    },
    {
      id: 'story-9',
      title: 'The Crystal Phoenix: Unveiling the 2026 Championship Trophy',
      category: 'Heritage',
      tagColor: '#FE5A00', // Flame orange
      date: 'Oct 14, 2026',
      readTime: '3 min read',
      author: 'Ananya Iyer',
      role: 'EC President',
      avatar: 'assets/heads/ec-president.jpg',
      image: 'assets/phoenix-crystal.png',
      excerpt: 'Crafted from obsidian glass and forged bronze, the 2026 Phoenix Trophy represents the apex of student athletic triumph.',
      content: `## The Symbol of Ultimate Collegiate Glory

Standing 28 inches tall and weighing 9 kilograms, the 2026 Kurukshetra Overall Champions Trophy has been officially unveiled by the Executive Committee.

Designed in collaboration with alumni sculptors, the trophy features a geometric crystal phoenix bursting forth from an obsidian pedestal. Inscribed around the base are the names of every past champion university since 2012.

Only one contingent will hoist this trophy on the evening of October 27. May the fiercest spirit triumph!`
    }
  ];

  // State Management
  let stories = [];
  let currentUser = null; // null = public visitor; or object { name, role, avatar }
  let activeCategory = 'all';
  let searchQuery = '';
  let activeSort = 'featured';
  let currentTheme = 'light';

  // DOM Elements
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const authBtn = document.getElementById('authBtn');
  const authBtnLabel = document.getElementById('authBtnLabel');
  const ecccAdminBanner = document.getElementById('ecccAdminBanner');
  const adminUserName = document.getElementById('adminUserName');
  const btnNewStoryHero = document.getElementById('btnNewStoryHero');
  const btnResetDefaults = document.getElementById('btnResetDefaults');
  const btnLogout = document.getElementById('btnLogout');
  const heroQuickActionBtn = document.getElementById('heroQuickActionBtn');
  const footerOpenAuthLink = document.getElementById('footerOpenAuthLink');

  const blogSearchInput = document.getElementById('blogSearchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  const blogSortSelect = document.getElementById('blogSortSelect');
  const postsCountBadge = document.getElementById('postsCountBadge');
  const categoryPillsRow = document.getElementById('categoryPillsRow');
  const blogCardsGrid = document.getElementById('blogCardsGrid');
  const emptyState = document.getElementById('emptyState');
  const btnResetFilters = document.getElementById('btnResetFilters');

  // Reader Modal Elements
  const readerModal = document.getElementById('readerModal');
  const closeReaderBtn = document.getElementById('closeReaderBtn');
  const closeReaderFooterBtn = document.getElementById('closeReaderFooterBtn');
  const readerCoverImg = document.getElementById('readerCoverImg');
  const readerCatBox = document.getElementById('readerCatBox');
  const readerCatText = document.getElementById('readerCatText');
  const readerDateText = document.getElementById('readerDateText');
  const readerReadTimeText = document.getElementById('readerReadTimeText');
  const readerTitle = document.getElementById('readerTitle');
  const readerAuthorAvatar = document.getElementById('readerAuthorAvatar');
  const readerAuthorName = document.getElementById('readerAuthorName');
  const readerAuthorRole = document.getElementById('readerAuthorRole');
  const readerExcerpt = document.getElementById('readerExcerpt');
  const readerContent = document.getElementById('readerContent');
  const readerAdminToolbar = document.getElementById('readerAdminToolbar');
  const btnReaderEdit = document.getElementById('btnReaderEdit');
  const btnReaderDelete = document.getElementById('btnReaderDelete');
  const btnCopyShareLink = document.getElementById('btnCopyShareLink');
  const btnTweetShare = document.getElementById('btnTweetShare');

  // Auth Modal Elements
  const authModal = document.getElementById('authModal');
  const closeAuthBtn = document.getElementById('closeAuthBtn');
  const authForm = document.getElementById('authForm');
  const passcodeInput = document.getElementById('passcodeInput');
  const togglePassVisibility = document.getElementById('togglePassVisibility');
  const authErrorMessage = document.getElementById('authErrorMessage');
  const demoAccountButtons = document.querySelectorAll('.btn-demo-account');

  // Editor Modal Elements (CRUD)
  const editorModal = document.getElementById('editorModal');
  const closeEditorBtn = document.getElementById('closeEditorBtn');
  const btnCancelEditor = document.getElementById('btnCancelEditor');
  const storyEditorForm = document.getElementById('storyEditorForm');
  const editorModalTitle = document.getElementById('editorModalTitle');
  const editingPostId = document.getElementById('editingPostId');
  const storyTitleInput = document.getElementById('storyTitleInput');
  const storyCategorySelect = document.getElementById('storyCategorySelect');
  const storyAuthorInput = document.getElementById('storyAuthorInput');
  const storyRoleInput = document.getElementById('storyRoleInput');
  const storyDateInput = document.getElementById('storyDateInput');
  const storyReadTimeInput = document.getElementById('storyReadTimeInput');
  const storyImageUrlInput = document.getElementById('storyImageUrlInput');
  const storyImageFileInput = document.getElementById('storyImageFileInput');
  const editorImagePreview = document.getElementById('editorImagePreview');
  const storyExcerptInput = document.getElementById('storyExcerptInput');
  const storyContentInput = document.getElementById('storyContentInput');
  const btnSaveStory = document.getElementById('btnSaveStory');
  const presetImagesStrip = document.getElementById('presetImagesStrip');

  // Delete Modal Elements
  const deleteModal = document.getElementById('deleteModal');
  const closeDeleteBtn = document.getElementById('btnCancelDelete');
  const btnConfirmDelete = document.getElementById('btnConfirmDelete');
  const deleteStoryTitleDisplay = document.getElementById('deleteStoryTitleDisplay');
  const deletingPostId = document.getElementById('deletingPostId');

  // Toast Container
  const toastContainer = document.getElementById('toastContainer');

  // -------------------------------------------------------------------------
  // Initialization & Storage
  // -------------------------------------------------------------------------
  function init() {
    initTheme();
    loadStories();
    loadAuth();
    attachEventListeners();
    render();
    checkUrlHashForPost();
  }

  function initTheme() {
    const savedTheme = localStorage.getItem(STORAGE_KEY_THEME);
    if (savedTheme) {
      currentTheme = savedTheme;
    } else {
      currentTheme = 'light'; // Default matches screenshot
    }
    applyTheme(currentTheme);
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.className = theme === 'dark' ? 'theme-dark' : 'theme-light';
    localStorage.setItem(STORAGE_KEY_THEME, theme);
  }

  function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
    showToast(`Switched to ${currentTheme === 'light' ? 'Light Editorial' : 'Obsidian Dark'} Theme`, 'info');
  }

  function loadStories() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_POSTS);
      if (stored) {
        stories = JSON.parse(stored);
      } else {
        stories = [...DEFAULT_STORIES];
        saveStories();
      }
    } catch (e) {
      console.error('Failed to parse stored stories, restoring defaults:', e);
      stories = [...DEFAULT_STORIES];
    }
  }

  function saveStories() {
    try {
      localStorage.setItem(STORAGE_KEY_POSTS, JSON.stringify(stories));
    } catch (e) {
      console.error('Failed to save stories to localStorage:', e);
    }
  }

  function loadAuth() {
    try {
      const storedAuth = localStorage.getItem(STORAGE_KEY_AUTH);
      if (storedAuth) {
        currentUser = JSON.parse(storedAuth);
      } else {
        currentUser = null;
      }
    } catch (e) {
      currentUser = null;
    }
    updateAuthUI();
  }

  function saveAuth(user) {
    currentUser = user;
    if (user) {
      localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY_AUTH);
    }
    updateAuthUI();
  }

  function updateAuthUI() {
    if (currentUser) {
      // User is EC/CC Member
      ecccAdminBanner.style.display = 'block';
      adminUserName.textContent = `${currentUser.name} (${currentUser.role})`;
      authBtnLabel.textContent = `${currentUser.name.split(' ')[0]} (EC/CC)`;
      authBtn.classList.add('active');
      if (heroQuickActionBtn) {
        heroQuickActionBtn.innerHTML = '<span>＋</span> Create Article';
      }
    } else {
      // Public Visitor Mode
      ecccAdminBanner.style.display = 'none';
      authBtnLabel.textContent = 'EC / CC Portal';
      authBtn.classList.remove('active');
      if (heroQuickActionBtn) {
        heroQuickActionBtn.innerHTML = '<span>✍️</span> EC/CC Member? Access Editor';
      }
    }
  }

  // -------------------------------------------------------------------------
  // Filtering, Searching & Sorting
  // -------------------------------------------------------------------------
  function getFilteredStories() {
    return stories.filter(story => {
      // Category match
      const matchCategory =
        activeCategory === 'all' ||
        story.category.toLowerCase() === activeCategory.toLowerCase();

      // Search match
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        story.title.toLowerCase().includes(q) ||
        story.category.toLowerCase().includes(q) ||
        (story.excerpt && story.excerpt.toLowerCase().includes(q)) ||
        (story.content && story.content.toLowerCase().includes(q)) ||
        (story.author && story.author.toLowerCase().includes(q));

      return matchCategory && matchSearch;
    }).sort((a, b) => {
      if (activeSort === 'featured') {
        return 0; // Preserves array order (newly created first, then reference cards)
      } else if (activeSort === 'newest') {
        return new Date(b.date || '1970').getTime() - new Date(a.date || '1970').getTime();
      } else if (activeSort === 'oldest') {
        return new Date(a.date || '1970').getTime() - new Date(b.date || '1970').getTime();
      } else if (activeSort === 'title') {
        return a.title.localeCompare(b.title);
      } else if (activeSort === 'readtime') {
        const timeA = parseInt(a.readTime, 10) || 5;
        const timeB = parseInt(b.readTime, 10) || 5;
        return timeA - timeB;
      }
      return 0;
    });
  }

  function updateCategoryCounts() {
    const counts = {
      all: stories.length,
      tools: 0,
      guides: 0,
      insights: 0,
      sports: 0,
      cultural: 0,
      heritage: 0
    };

    stories.forEach(s => {
      const cat = (s.category || '').toLowerCase();
      if (counts.hasOwnProperty(cat)) {
        counts[cat]++;
      }
    });

    Object.keys(counts).forEach(k => {
      const el = document.getElementById(`count-${k}`);
      if (el) {
        el.textContent = counts[k];
      }
    });
  }

  // -------------------------------------------------------------------------
  // Render Function (Recreating reference mockup card design)
  // -------------------------------------------------------------------------
  function render() {
    updateCategoryCounts();
    const filtered = getFilteredStories();

    // Update count badge
    if (postsCountBadge) {
      postsCountBadge.textContent = `Showing ${filtered.length} ${filtered.length === 1 ? 'Story' : 'Stories'}`;
    }

    // Toggle Empty State
    if (filtered.length === 0) {
      blogCardsGrid.innerHTML = '';
      emptyState.style.display = 'block';
      return;
    }

    emptyState.style.display = 'none';

    // Build Cards HTML
    blogCardsGrid.innerHTML = filtered.map(story => {
      const tagColor = story.tagColor || '#FE5A00';
      const readTime = story.readTime || '5 min read';
      const isEcCc = !!currentUser;

      // EC/CC action buttons on card (Edit / Delete)
      const adminActionsHtml = isEcCc ? `
        <div class="card-admin-actions" onclick="event.stopPropagation()">
          <button class="card-admin-btn btn-card-edit" title="Edit story (EC/CC)" data-id="${story.id}">✏️</button>
          <button class="card-admin-btn btn-card-delete" title="Delete story (EC/CC)" data-id="${story.id}">🗑️</button>
        </div>
      ` : '';

      return `
        <article class="blog-card" data-id="${story.id}">
          ${adminActionsHtml}

          <!-- Image Container with Rounded Corners (matching reference) -->
          <div class="blog-card-media">
            <img 
              src="${escapeHtml(story.image)}" 
              alt="${escapeHtml(story.title)}" 
              class="blog-card-img" 
              loading="lazy"
              onerror="this.src='assets/hero-player.png'"
            >
          </div>

          <!-- Body Content -->
          <div class="blog-card-body">
            <!-- Headline / Title -->
            <h2 class="blog-card-title">${escapeHtml(story.title)}</h2>

            <!-- Bottom Meta Row: Colored square + Category name + Date -->
            <div class="blog-card-meta">
              <div class="meta-category-group">
                <span class="meta-color-square" style="background-color: ${escapeHtml(tagColor)};"></span>
                <span>${escapeHtml(story.category)}</span>
              </div>
              <span class="meta-date">${escapeHtml(story.date)}</span>
              <span class="meta-readtime">${escapeHtml(readTime)}</span>
            </div>
          </div>
        </article>
      `;
    }).join('');

    // Attach card click listeners
    const cards = blogCardsGrid.querySelectorAll('.blog-card');
    cards.forEach(card => {
      card.addEventListener('click', (e) => {
        // Prevent if clicked on admin actions
        if (e.target.closest('.card-admin-actions')) return;
        const id = card.getAttribute('data-id');
        openReader(id);
      });
    });

    // Attach edit and delete listeners
    if (currentUser) {
      blogCardsGrid.querySelectorAll('.btn-card-edit').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-id');
          openEditor(id);
        });
      });

      blogCardsGrid.querySelectorAll('.btn-card-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-id');
          openDeleteDialog(id);
        });
      });
    }
  }

  // -------------------------------------------------------------------------
  // Article Reader Modal (Full View for All)
  // -------------------------------------------------------------------------
  function openReader(id) {
    const story = stories.find(s => s.id === id);
    if (!story) return;

    readerCoverImg.src = story.image || 'assets/hero-player.png';
    readerCatBox.style.backgroundColor = story.tagColor || '#FE5A00';
    readerCatText.textContent = story.category;
    readerDateText.textContent = story.date;
    readerReadTimeText.textContent = story.readTime || '5 min read';
    readerTitle.textContent = story.title;

    readerAuthorAvatar.src = story.avatar || 'assets/heads/cc-tech.jpg';
    readerAuthorAvatar.onerror = function () { this.src = 'assets/heads/ec-president.jpg'; };
    readerAuthorName.textContent = story.author || 'FLAME Kurukshetra Committee';
    readerAuthorRole.textContent = story.role || 'Executive Committee';

    readerExcerpt.textContent = story.excerpt || '';

    // Format content (Markdown-like parser)
    readerContent.innerHTML = formatProse(story.content || story.excerpt || '');

    // Show EC/CC tools inside reader if authorized
    if (currentUser) {
      readerAdminToolbar.style.display = 'flex';
      btnReaderEdit.onclick = () => {
        closeReader();
        openEditor(story.id);
      };
      btnReaderDelete.onclick = () => {
        closeReader();
        openDeleteDialog(story.id);
      };
    } else {
      readerAdminToolbar.style.display = 'none';
    }

    // Share action setup
    btnCopyShareLink.onclick = () => {
      const url = `${window.location.origin}${window.location.pathname}#${story.id}`;
      navigator.clipboard.writeText(url).then(() => {
        showToast('Story link copied to clipboard!', 'success');
      }).catch(() => {
        showToast('Link copied: ' + url, 'info');
      });
    };

    btnTweetShare.onclick = () => {
      const text = encodeURIComponent(`Read "${story.title}" on FLAME Kurukshetra Chronicles:\n`);
      const url = encodeURIComponent(window.location.href);
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
    };

    // Update URL hash without reload
    history.replaceState(null, '', `#${story.id}`);

    readerModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  function closeReader() {
    readerModal.style.display = 'none';
    document.body.style.overflow = '';
    history.replaceState(null, '', window.location.pathname);
  }

  function formatProse(raw) {
    if (!raw) return '';
    const lines = raw.split('\n\n');
    return lines.map(block => {
      block = block.trim();
      if (!block) return '';

      // H2 Headings
      if (block.startsWith('## ')) {
        return `<h2>${escapeHtml(block.replace('## ', ''))}</h2>`;
      }
      // H3 Headings
      if (block.startsWith('### ')) {
        return `<h3 style="margin:20px 0 10px 0; font-family:var(--font-display);">${escapeHtml(block.replace('### ', ''))}</h3>`;
      }
      // Blockquote
      if (block.startsWith('> ')) {
        return `<blockquote>${escapeHtml(block.replace('> ', ''))}</blockquote>`;
      }
      // List
      if (block.startsWith('- ') || block.startsWith('* ')) {
        const items = block.split('\n').map(li => `<li>${escapeHtml(li.replace(/^[-*]\s*/, ''))}</li>`).join('');
        return `<ul>${items}</ul>`;
      }

      // Standard paragraph with bold/italic inline support
      let parsed = escapeHtml(block);
      parsed = parsed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      parsed = parsed.replace(/\*(.*?)\*/g, '<em>$1</em>');
      parsed = parsed.replace(/`(.*?)`/g, '<code>$1</code>');
      return `<p>${parsed}</p>`;
    }).join('');
  }

  function checkUrlHashForPost() {
    const hash = window.location.hash.replace('#', '');
    if (hash) {
      const match = stories.find(s => s.id === hash);
      if (match) {
        openReader(match.id);
      }
    }
  }

  // -------------------------------------------------------------------------
  // EC / CC Authentication Modal
  // -------------------------------------------------------------------------
  function openAuthModal() {
    authErrorMessage.style.display = 'none';
    passcodeInput.value = '';
    authModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    passcodeInput.focus();
  }

  function closeAuthModal() {
    authModal.style.display = 'none';
    document.body.style.overflow = '';
  }

  function handleAuthSubmit(e) {
    e.preventDefault();
    const entered = (passcodeInput.value || '').trim().toLowerCase();
    if (VALID_PASSCODES.includes(entered)) {
      const user = {
        name: 'Ritisha Singh',
        role: 'CC Tech Head',
        avatar: 'assets/heads/cc-tech.jpg'
      };
      saveAuth(user);
      closeAuthModal();
      render();
      showToast('Authenticated as CC Tech Head! Full CRUD unlocked.', 'success');
    } else {
      authErrorMessage.style.display = 'block';
    }
  }

  function handleDemoLogin(name, role, avatar) {
    const user = { name, role, avatar };
    saveAuth(user);
    closeAuthModal();
    render();
    showToast(`Logged in as ${name} (${role})! Full CRUD unlocked.`, 'success');
  }

  function logout() {
    saveAuth(null);
    render();
    showToast('Logged out from EC/CC mode. Read-only visitor view active.', 'info');
  }

  // -------------------------------------------------------------------------
  // Create / Update Article (CRUD)
  // -------------------------------------------------------------------------
  function openEditor(postId = null) {
    if (!currentUser) {
      openAuthModal();
      return;
    }

    storyEditorForm.reset();
    authErrorMessage.style.display = 'none';

    // Reset presets active state
    presetImagesStrip.querySelectorAll('.btn-preset-img').forEach(btn => btn.classList.remove('active'));

    if (postId) {
      // UPDATE MODE
      const story = stories.find(s => s.id === postId);
      if (!story) return;

      editorModalTitle.textContent = 'Edit Article';
      btnSaveStory.textContent = 'Save Changes';
      editingPostId.value = story.id;

      storyTitleInput.value = story.title;
      storyCategorySelect.value = story.category;

      // Tag color radio
      const radio = document.querySelector(`input[name="tagColor"][value="${story.tagColor}"]`);
      if (radio) {
        radio.checked = true;
      }

      storyAuthorInput.value = story.author || currentUser.name;
      storyRoleInput.value = story.role || currentUser.role;
      storyDateInput.value = story.date || getTodayFormatted();
      storyReadTimeInput.value = story.readTime || '5 min read';

      storyImageUrlInput.value = story.image;
      editorImagePreview.src = story.image;

      storyExcerptInput.value = story.excerpt || '';
      storyContentInput.value = story.content || '';

      // Highlight preset button if matches
      const matchingPreset = presetImagesStrip.querySelector(`[data-img="${story.image}"]`);
      if (matchingPreset) {
        matchingPreset.classList.add('active');
      }
    } else {
      // CREATE MODE
      editorModalTitle.textContent = 'Create New Article';
      btnSaveStory.textContent = 'Publish to Newsroom';
      editingPostId.value = '';

      storyAuthorInput.value = currentUser.name;
      storyRoleInput.value = currentUser.role;
      storyDateInput.value = getTodayFormatted();
      storyReadTimeInput.value = '5 min read';

      // Default preset
      const firstPreset = presetImagesStrip.querySelector('.btn-preset-img');
      if (firstPreset) {
        firstPreset.classList.add('active');
        const defaultImg = firstPreset.getAttribute('data-img');
        storyImageUrlInput.value = defaultImg;
        editorImagePreview.src = defaultImg;
      }
    }

    editorModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    storyTitleInput.focus();
  }

  function closeEditor() {
    editorModal.style.display = 'none';
    document.body.style.overflow = '';
  }

  function handleSaveStory(e) {
    e.preventDefault();

    const title = storyTitleInput.value.trim();
    const category = storyCategorySelect.value;
    const selectedColorEl = document.querySelector('input[name="tagColor"]:checked');
    const tagColor = selectedColorEl ? selectedColorEl.value : '#FE5A00';
    const author = storyAuthorInput.value.trim();
    const role = storyRoleInput.value.trim() || 'EC / CC Member';
    const date = storyDateInput.value.trim() || getTodayFormatted();
    const readTime = storyReadTimeInput.value.trim() || '5 min read';
    const image = storyImageUrlInput.value.trim() || 'assets/hero-player.png';
    const excerpt = storyExcerptInput.value.trim();
    const content = storyContentInput.value.trim();

    const isEditing = !!editingPostId.value;

    if (isEditing) {
      // UPDATE
      const id = editingPostId.value;
      const index = stories.findIndex(s => s.id === id);
      if (index !== -1) {
        stories[index] = {
          ...stories[index],
          title,
          category,
          tagColor,
          author,
          role,
          date,
          readTime,
          image,
          excerpt,
          content
        };
        saveStories();
        showToast('Story updated successfully!', 'success');
      }
    } else {
      // CREATE
      const newId = 'story-' + Date.now();
      const newPost = {
        id: newId,
        title,
        category,
        tagColor,
        author,
        role,
        avatar: currentUser.avatar || 'assets/heads/cc-tech.jpg',
        date,
        readTime,
        image,
        excerpt,
        content
      };
      stories.unshift(newPost);
      saveStories();
      showToast('New story published to newsroom!', 'success');
    }

    closeEditor();
    render();
  }

  // -------------------------------------------------------------------------
  // Delete Article (CRUD)
  // -------------------------------------------------------------------------
  function openDeleteDialog(id) {
    if (!currentUser) {
      openAuthModal();
      return;
    }

    const story = stories.find(s => s.id === id);
    if (!story) return;

    deletingPostId.value = story.id;
    deleteStoryTitleDisplay.textContent = `"${story.title}"`;

    deleteModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  function closeDeleteDialog() {
    deleteModal.style.display = 'none';
    document.body.style.overflow = '';
  }

  function confirmDeleteStory() {
    const id = deletingPostId.value;
    if (!id) return;

    const index = stories.findIndex(s => s.id === id);
    if (index !== -1) {
      const removed = stories.splice(index, 1)[0];
      saveStories();
      showToast(`Deleted story "${removed.title.substring(0, 25)}..."`, 'info');
      closeDeleteDialog();
      render();
    }
  }

  // -------------------------------------------------------------------------
  // Reset Defaults
  // -------------------------------------------------------------------------
  function resetToDefaults() {
    if (confirm('Reset all stories back to official Kurukshetra festival defaults? Any custom added stories will be replaced.')) {
      stories = [...DEFAULT_STORIES];
      saveStories();
      render();
      showToast('All stories reset to festival defaults!', 'success');
    }
  }

  // -------------------------------------------------------------------------
  // Helper Utilities
  // -------------------------------------------------------------------------
  function getTodayFormatted() {
    const d = new Date();
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = 'toast';
    const icon = type === 'success' ? '✅' : type === 'error' ? '⚠️' : '🔥';
    toast.innerHTML = `<span>${icon}</span> <span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('toast-fadeout');
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, 3200);
  }

  // -------------------------------------------------------------------------
  // Event Listeners Attachment
  // -------------------------------------------------------------------------
  function attachEventListeners() {
    // Theme toggle
    if (themeToggleBtn) {
      themeToggleBtn.addEventListener('click', toggleTheme);
    }

    // Auth Button in Navbar
    if (authBtn) {
      authBtn.addEventListener('click', () => {
        if (currentUser) {
          showToast(`Logged in as ${currentUser.name} (${currentUser.role})`, 'info');
        } else {
          openAuthModal();
        }
      });
    }

    if (footerOpenAuthLink) {
      footerOpenAuthLink.addEventListener('click', openAuthModal);
    }

    // Hero trigger
    if (heroQuickActionBtn) {
      heroQuickActionBtn.addEventListener('click', () => {
        if (currentUser) {
          openEditor();
        } else {
          openAuthModal();
        }
      });
    }

    // Admin Banner Actions
    if (btnNewStoryHero) {
      btnNewStoryHero.addEventListener('click', () => openEditor());
    }
    if (btnResetDefaults) {
      btnResetDefaults.addEventListener('click', resetToDefaults);
    }
    if (btnLogout) {
      btnLogout.addEventListener('click', logout);
    }

    // Search Input
    if (blogSearchInput) {
      blogSearchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value;
        if (clearSearchBtn) {
          clearSearchBtn.style.display = searchQuery ? 'block' : 'none';
        }
        render();
      });
    }

    if (clearSearchBtn) {
      clearSearchBtn.addEventListener('click', () => {
        blogSearchInput.value = '';
        searchQuery = '';
        clearSearchBtn.style.display = 'none';
        render();
        blogSearchInput.focus();
      });
    }

    // Sort Dropdown
    if (blogSortSelect) {
      blogSortSelect.addEventListener('change', (e) => {
        activeSort = e.target.value;
        render();
      });
    }

    // Category Filter Pills
    if (categoryPillsRow) {
      categoryPillsRow.querySelectorAll('.cat-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          categoryPillsRow.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
          pill.classList.add('active');
          activeCategory = pill.getAttribute('data-category');
          render();
        });
      });
    }

    if (btnResetFilters) {
      btnResetFilters.addEventListener('click', () => {
        activeCategory = 'all';
        searchQuery = '';
        if (blogSearchInput) blogSearchInput.value = '';
        if (clearSearchBtn) clearSearchBtn.style.display = 'none';
        categoryPillsRow.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
        const allPill = categoryPillsRow.querySelector('[data-category="all"]');
        if (allPill) allPill.classList.add('active');
        render();
      });
    }

    // Reader Modal Closers
    if (closeReaderBtn) closeReaderBtn.addEventListener('click', closeReader);
    if (closeReaderFooterBtn) closeReaderFooterBtn.addEventListener('click', closeReader);
    readerModal.addEventListener('click', (e) => {
      if (e.target === readerModal) closeReader();
    });

    // Auth Modal Closers & Actions
    if (closeAuthBtn) closeAuthBtn.addEventListener('click', closeAuthModal);
    authModal.addEventListener('click', (e) => {
      if (e.target === authModal) closeAuthModal();
    });
    if (authForm) authForm.addEventListener('submit', handleAuthSubmit);

    // Toggle Pass Visibility
    if (togglePassVisibility) {
      togglePassVisibility.addEventListener('click', () => {
        passcodeInput.type = passcodeInput.type === 'password' ? 'text' : 'password';
      });
    }

    // Demo Account Buttons
    demoAccountButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.getAttribute('data-name');
        const role = btn.getAttribute('data-role');
        const avatar = btn.getAttribute('data-avatar');
        handleDemoLogin(name, role, avatar);
      });
    });

    // Editor Modal Closers & Form
    if (closeEditorBtn) closeEditorBtn.addEventListener('click', closeEditor);
    if (btnCancelEditor) btnCancelEditor.addEventListener('click', closeEditor);
    editorModal.addEventListener('click', (e) => {
      if (e.target === editorModal) closeEditor();
    });
    if (storyEditorForm) storyEditorForm.addEventListener('submit', handleSaveStory);

    // Preset Image Chooser
    if (presetImagesStrip) {
      presetImagesStrip.querySelectorAll('.btn-preset-img').forEach(btn => {
        btn.addEventListener('click', () => {
          presetImagesStrip.querySelectorAll('.btn-preset-img').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const src = btn.getAttribute('data-img');
          storyImageUrlInput.value = src;
          editorImagePreview.src = src;
        });
      });
    }

    // Custom Image URL Input
    if (storyImageUrlInput) {
      storyImageUrlInput.addEventListener('input', (e) => {
        const url = e.target.value.trim();
        if (url) {
          editorImagePreview.src = url;
          presetImagesStrip.querySelectorAll('.btn-preset-img').forEach(b => b.classList.remove('active'));
        }
      });
    }

    // Local Image Upload Input (converts to base64)
    if (storyImageFileInput) {
      storyImageFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const dataUrl = event.target.result;
            storyImageUrlInput.value = dataUrl;
            editorImagePreview.src = dataUrl;
            presetImagesStrip.querySelectorAll('.btn-preset-img').forEach(b => b.classList.remove('active'));
          };
          reader.readAsDataURL(file);
        }
      });
    }

    // Formatting Toolbar Buttons
    document.querySelectorAll('.btn-fmt').forEach(btn => {
      btn.addEventListener('click', () => {
        const fmt = btn.getAttribute('data-format');
        const textarea = storyContentInput;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selected = textarea.value.substring(start, end) || 'text';
        let insertion = '';

        if (fmt === 'h2') insertion = `\n\n## ${selected}\n\n`;
        else if (fmt === 'bold') insertion = `**${selected}**`;
        else if (fmt === 'quote') insertion = `\n\n> "${selected}"\n\n`;
        else if (fmt === 'bullet') insertion = `\n- ${selected}\n- point 2\n`;
        else if (fmt === 'phoenix') insertion = `\n\n> "Rise like the Phoenix — grit meets greatness at Kurukshetra."\n\n`;

        textarea.setRangeText(insertion, start, end, 'end');
        textarea.focus();
      });
    });

    // Delete Modal Closers & Action
    if (closeDeleteBtn) closeDeleteBtn.addEventListener('click', closeDeleteDialog);
    deleteModal.addEventListener('click', (e) => {
      if (e.target === deleteModal) closeDeleteDialog();
    });
    if (btnConfirmDelete) btnConfirmDelete.addEventListener('click', confirmDeleteStory);

    // Escape Key Listener to Close Any Active Modal
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeReader();
        closeAuthModal();
        closeEditor();
        closeDeleteDialog();
      }
    });
  }

  // Self-start on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
